"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { FormEvent, useEffect, useState } from "react";

type AuthFormProps = {
  mode: "login" | "register";
};

type ErrorField = "displayName" | "identity" | "password" | "confirmPassword";

function FieldError({ message }: { message: string }) {
  return (
    <span
      role="alert"
      className="absolute bottom-full right-1/2 z-20 mb-3 flex w-[min(320px,calc(100vw-32px))] translate-x-1/2 items-center gap-2.5 rounded-xl border-2 border-[#cfd3d9] bg-white px-3 py-2.5 text-center text-xs font-bold text-[#111827] shadow-[0_10px_20px_rgba(20,30,45,0.16)] before:absolute before:-bottom-[10px] before:right-1/2 before:size-4 before:translate-x-1/2 before:rotate-45 before:border-b-2 before:border-r-2 before:border-[#cfd3d9] before:bg-white"
    >
      <span className="relative z-10 flex size-8 shrink-0 items-center justify-center rounded-xl bg-[#f59a00] text-xl font-extrabold text-white">
        !
      </span>
      <span className="relative z-10 flex-1">{message}</span>
    </span>
  );
}

export function AuthForm({ mode }: AuthFormProps) {
  const isLogin = mode === "login";
  const router = useRouter();
  const pathname = usePathname();
  const [messageVisible, setMessageVisible] = useState(false);
  const [serverMessage, setServerMessage] = useState<string | null>(null);
  const [errorField, setErrorField] = useState<ErrorField | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    let active = true;
    fetch("/api/auth/me")
      .then((response) => response.json())
      .then((data) => {
        if (active && data.user) router.replace("/");
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, [pathname, router]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    setServerMessage(null);
    setMessageVisible(false);
    const fields: ErrorField[] = isLogin
      ? ["identity", "password"]
      : ["displayName", "identity", "password", "confirmPassword"];
    const emptyField = fields.find((field) => !String(formData.get(field) ?? "").trim());

    if (emptyField) {
      setErrorField(emptyField);
      setMessageVisible(false);
      return;
    }

    setErrorField(null);
    setIsSubmitting(true);

    try {
      const response = await fetch(`/api/auth/${isLogin ? "login" : "register"}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.get("displayName"),
          identity: formData.get("identity"),
          password: formData.get("password"),
          confirmPassword: formData.get("confirmPassword"),
        }),
      });
      const result = await response.json();
      if (!response.ok) {
        setServerMessage(result.message ?? "عملیات انجام نشد.");
        return;
      }
      router.replace("/");
      router.refresh();
    } catch {
      setServerMessage("ارتباط با سرور برقرار نشد.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="h-dvh overflow-hidden bg-white text-[#090909]" dir="rtl">
      <div className="mx-auto h-full w-full max-w-[520px] bg-white px-4 pb-8 sm:px-7">
        <div className="flex h-full flex-col pt-28">
          <section className="mt-0 min-h-0">
            <div className="mb-8 text-center">
              <h1 className="text-[27px] font-bold leading-[1.4] tracking-tight sm:text-[30px]">
                {isLogin ? "ورود به حساب" : "ایجاد حساب کاربری"}
              </h1>
              <p className="mt-2 text-base font-medium leading-7 text-[#a5a5af] sm:text-lg">
                {isLogin ? "به حساب خود وارد شوید" : "به جمع ما بپیوندید"}
              </p>
            </div>

            <form className="space-y-3" onSubmit={handleSubmit}>
              {!isLogin && (
                <label className="relative block">
                  <span className="sr-only">نام نمایشی</span>
                  <input
                    name="displayName"
                    type="text"
                    placeholder="نام نمایشی"
                    onChange={() => { setErrorField(null); setServerMessage(null); }}
                    className="h-14 w-full rounded-2xl border-2 border-[#e7e7e7] bg-white px-5 text-right text-sm sm:text-base outline-none transition-colors placeholder:text-[#a5a5af] focus:border-[#b7b7c0]"
                  />
                  {errorField === "displayName" && <FieldError message="نام نمایشی را وارد کنید." />}
                </label>
              )}

              <label className="relative block">
                <span className="sr-only">شماره موبایل یا ایمیل</span>
                <input
                  name="identity"
                  type="text"
                  placeholder="شماره موبایل یا ایمیل"
                  onChange={() => setErrorField(null)}
                  className="h-14 w-full rounded-2xl border-2 border-[#e7e7e7] bg-white px-5 text-right text-sm sm:text-base outline-none transition-colors placeholder:text-[#a5a5af] focus:border-[#b7b7c0]"
                />
                {errorField === "identity" && <FieldError message="شماره موبایل یا ایمیل را وارد کنید." />}
              </label>

              <label className="relative block">
                <span className="sr-only">رمز عبور</span>
                <input
                  name="password"
                  type="password"
                  placeholder="رمز عبور"
                  onChange={() => setErrorField(null)}
                  className="h-14 w-full rounded-2xl border-2 border-[#e7e7e7] bg-white px-5 text-right text-sm sm:text-base outline-none transition-colors placeholder:text-[#a5a5af] focus:border-[#b7b7c0]"
                />
                {errorField === "password" && <FieldError message="رمز عبور را وارد کنید." />}
              </label>

              {!isLogin && (
                <label className="relative block">
                  <span className="sr-only">تایید رمز عبور</span>
                  <input
                    name="confirmPassword"
                    type="password"
                    placeholder="تایید رمز عبور"
                    onChange={() => { setErrorField(null); setServerMessage(null); }}
                    className="h-14 w-full rounded-2xl border-2 border-[#e7e7e7] bg-white px-5 text-right text-sm sm:text-base outline-none transition-colors placeholder:text-[#a5a5af] focus:border-[#b7b7c0]"
                  />
                  {errorField === "confirmPassword" && <FieldError message="تأیید رمز عبور را وارد کنید." />}
                </label>
              )}

              <button
                type="submit"
                className="h-12 w-full rounded-2xl bg-[#090909] text-base font-bold text-white shadow-[0_22px_42px_rgba(0,0,0,0.16)] transition-transform active:scale-[0.99]"
              >
                {isSubmitting ? "لطفاً صبر کنید..." : isLogin ? "ورود به حساب" : "ساخت حساب"}
              </button>
            </form>

            {(messageVisible || serverMessage) && (
              <div className={`mt-5 rounded-2xl px-4 py-3 text-center text-sm leading-6 ${serverMessage ? "bg-[#fff0f0] text-[#b42318]" : "bg-[#fff6e8] text-[#9a6a19]"}`}>
                {serverMessage ?? "این قابلیت هنوز فعال نشده است و در مرحله بعد اضافه می‌شود."}
              </div>
            )}

            <p className="mt-7 pb-4 text-center text-sm leading-7 text-[#a5a5af]">
              {isLogin ? "حساب کاربری نداری؟" : "حساب داری؟"}{" "}
              <Link
                href={isLogin ? "/register" : "/login"}
                className="font-bold text-[#4c4c55] transition-colors hover:text-black"
              >
                {isLogin ? "ایجاد حساب کاربری" : "وارد شوید"}
              </Link>
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
