"use client";

import Link from "next/link";
import {
  Bell,
  Bot,
  Check,
  ChevronDown,
  ChevronLeft,
  CircleHelp,
  Headphones,
  Menu,
  MessageCircle,
  Plus,
  Settings,
  Smartphone,
  Sparkles,
  Trash2,
  Wrench,
  UserRound,
  X,
} from "lucide-react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type ChatHistoryItem = {
  publicId: string;
  title: string;
};

type PublicAiModel = {
  id: string;
  name: string;
  apiModel: string;
  status: string;
  builtIn: boolean;
  icon: string | null;
};

function GeminiModelIcon() {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      fill="none"
      className="size-3.5 shrink-0"
    >
      <path
        d="M12 2.35c.75 4.85 3.55 7.65 8.4 8.4-4.85.75-7.65 3.55-8.4 8.4-.75-4.85-3.55-7.65-8.4-8.4 4.85-.75 7.65-3.55 8.4-8.4Z"
        fill="url(#gemini-icon-gradient)"
      />
      <defs>
        <linearGradient
          id="gemini-icon-gradient"
          x1="3.6"
          y1="3.2"
          x2="19.7"
          y2="18.9"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#4285f4" />
          <stop offset="0.42" stopColor="#a142f4" />
          <stop offset="0.72" stopColor="#ea4335" />
          <stop offset="1" stopColor="#fbbc04" />
        </linearGradient>
      </defs>
    </svg>
  );
}
function ModelIcon({ model }: { model: PublicAiModel }) {
  if (model.icon && model.icon !== "gemini") {
    return (
      <span className="flex size-3.5 shrink-0 overflow-hidden rounded-md bg-[#f3f6ff]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={model.icon} alt="" className="size-full object-cover" />
      </span>
    );
  }
  return <GeminiModelIcon />;
}

export function AppHeader() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuClosing, setMenuClosing] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastClosing, setToastClosing] = useState(false);
  const [closeRipple, setCloseRipple] = useState<{
    x: number;
    y: number;
    size: number;
  } | null>(null);
  const [currentUser, setCurrentUser] = useState<{
    name: string;
    email: string;
  } | null>(null);
  const [logoutRipple, setLogoutRipple] = useState<{
    x: number;
    y: number;
    size: number;
  } | null>(null);
  const [assistantsOpen, setAssistantsOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [modelSelectorOpen, setModelSelectorOpen] = useState(false);
  const [aiModels, setAiModels] = useState<PublicAiModel[]>([]);
  const [selectedModelId, setSelectedModelId] = useState(
    "system-gemini-3-1-flash-lite",
  );
  const [chatHistory, setChatHistory] = useState<ChatHistoryItem[]>([]);
  const [deletingChat, setDeletingChat] = useState<string | null>(null);
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const router = useRouter();
  const showModelSelector = pathname === "/" && !searchParams.get("m");
  const selectedModel = aiModels.find(
    (model) => model.id === selectedModelId,
  ) ??
    aiModels[0] ?? {
      id: "system-gemini-3-1-flash-lite",
      name: "Gemini 3.1 Flash Lite",
      apiModel: "gemini-3.1-flash-lite",
      status: "active",
      builtIn: true,
      icon: "gemini",
    };

  useEffect(() => {
    if (showModelSelector) return;
    const timer = window.setTimeout(() => setModelSelectorOpen(false), 0);
    return () => window.clearTimeout(timer);
  }, [showModelSelector]);

  useEffect(() => {
    if (!showModelSelector) return;
    let active = true;
    fetch("/api/models", { cache: "no-store" })
      .then((response) => response.json())
      .then((data) => {
        if (!active) return;
        const items = (data.items ?? []) as PublicAiModel[];
        setAiModels(items);
        const saved = localStorage.getItem("megastars:selected-model-id");
        const next =
          items.find(
            (model) => model.id === saved && model.status === "active",
          ) ??
          items.find((model) => model.status === "active") ??
          items[0];
        if (next) setSelectedModelId(next.id);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, [showModelSelector, modelSelectorOpen]);

  function chooseModel(model: PublicAiModel) {
    if (model.status !== "active") return;
    setSelectedModelId(model.id);
    localStorage.setItem("megastars:selected-model-id", model.id);
    window.dispatchEvent(
      new CustomEvent("megastars:model-selected", { detail: model }),
    );
    setModelSelectorOpen(false);
  }

  useEffect(() => {
    fetch("/api/auth/me")
      .then((response) => response.json())
      .then((data) => setCurrentUser(data.user))
      .catch(() => setCurrentUser(null));
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  useEffect(() => {
    if (!toastVisible) return;
    const timer = window.setTimeout(() => closeToast(), 3200);
    return () => window.clearTimeout(timer);
  }, [toastVisible]);

  useEffect(() => {
    if (!menuOpen || !currentUser) return;
    let active = true;
    fetch("/api/chats", { cache: "no-store" })
      .then((response) => (response.ok ? response.json() : { items: [] }))
      .then((data) => {
        if (active) setChatHistory(data.items ?? []);
      })
      .catch(() => {
        if (active) setChatHistory([]);
      });
    return () => {
      active = false;
    };
  }, [menuOpen, currentUser]);

  function openMenu() {
    setMenuClosing(false);
    setMenuOpen(true);
  }

  function handleLogoutRipple(event: React.PointerEvent<HTMLButtonElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2.2;
    setLogoutRipple({
      x: event.clientX - rect.left - size / 2,
      y: event.clientY - rect.top - size / 2,
      size,
    });
    window.setTimeout(() => setLogoutRipple(null), 450);
  }

  async function handleLogout() {
    closeMenu();
    await new Promise((resolve) => window.setTimeout(resolve, 280));
    await fetch("/api/auth/logout", { method: "POST" });
    setCurrentUser(null);
    router.refresh();
  }

  async function deleteChat(publicId: string) {
    if (deletingChat) return;
    setDeletingChat(publicId);
    try {
      const response = await fetch(
        `/api/chats/${encodeURIComponent(publicId)}`,
        { method: "DELETE" },
      );
      if (!response.ok) return;
      setChatHistory((current) =>
        current.filter((chat) => chat.publicId !== publicId),
      );
      if (
        typeof window !== "undefined" &&
        new URLSearchParams(window.location.search).get("m") === publicId
      ) {
        window.dispatchEvent(new Event("megastars:new-chat"));
        router.replace("/");
      }
    } finally {
      setDeletingChat(null);
    }
  }

  function handleCloseRipple(event: React.PointerEvent<HTMLButtonElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2.2;
    setCloseRipple({
      x: event.clientX - rect.left - size / 2,
      y: event.clientY - rect.top - size / 2,
      size,
    });
    window.setTimeout(() => setCloseRipple(null), 450);
  }

  function closeMenu() {
    setMenuClosing(true);
    window.setTimeout(() => {
      setMenuOpen(false);
      setMenuClosing(false);
    }, 260);
  }

  function openToast() {
    setToastClosing(false);
    setToastVisible(true);
  }

  function closeToast() {
    setToastClosing(true);
    window.setTimeout(() => {
      setToastVisible(false);
      setToastClosing(false);
    }, 280);
  }

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-30 mx-auto flex h-20 w-full items-center justify-between bg-transparent px-5 sm:px-7">
        <div className="flex items-center gap-2">
          <button
            type="button"
            aria-label="باز کردن منو"
            onClick={openMenu}
            className="flex size-11 items-center justify-center rounded-2xl border border-[#edf0f6] bg-white text-[#1f376d] shadow-[0_6px_18px_rgba(45,74,130,0.06)] transition-transform active:scale-95"
          >
            <Menu className="size-[22px]" strokeWidth={1.8} />
          </button>

          {showModelSelector && (
            <DropdownMenu
              open={modelSelectorOpen}
              onOpenChange={setModelSelectorOpen}
            >
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  aria-label="انتخاب مدل"
                  className="flex h-9 min-w-[138px] items-center justify-start gap-1 px-0.5 text-[9px] font-bold whitespace-nowrap text-[#172342] outline-none transition-colors [-webkit-tap-highlight-color:transparent] focus:outline-none focus-visible:outline-none"
                >
                  <span>{selectedModel.name}</span>
                  <ChevronDown
                    className={`size-3 shrink-0 text-[#8f96a3] transition-transform duration-200 ease-out ${modelSelectorOpen ? "rotate-180" : "rotate-0"}`}
                    strokeWidth={2.2}
                  />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="start"
                side="bottom"
                sideOffset={2}
                className="w-[190px] min-w-[190px] rounded-lg border-[#edf0f6] bg-white/95 p-1 shadow-[0_10px_24px_rgba(16,26,53,0.1)] backdrop-blur-md"
              >
                {(aiModels.length ? aiModels : [selectedModel]).map((model) => (
                  <DropdownMenuItem
                    key={model.id}
                    disabled={model.status !== "active"}
                    onSelect={(event) => {
                      event.preventDefault();
                      chooseModel(model);
                    }}
                    className={`grid cursor-default grid-cols-[16px_1fr_14px] items-center gap-2 rounded-md px-2 py-1.5 text-left text-[11px] leading-none text-[#242831] focus:bg-[#f7f9ff] ${model.status !== "active" ? "opacity-45" : ""}`}
                  >
                    <ModelIcon model={model} />
                    <span className="whitespace-nowrap font-bold text-[#172342]">
                      {model.name}
                    </span>
                    {model.id === selectedModel.id && (
                      <Check
                        className="size-3.5 shrink-0 text-[#2f6af4]"
                        strokeWidth={2.2}
                      />
                    )}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        <button
          type="button"
          aria-label="اعلان‌ها"
          onClick={openToast}
          className="relative flex size-11 items-center justify-center rounded-2xl border border-[#edf0f6] bg-white text-[#1f376d] shadow-[0_6px_18px_rgba(45,74,130,0.06)] transition-transform active:scale-95"
        >
          <Bell className="size-[21px]" strokeWidth={1.8} />
        </button>
      </header>

      {toastVisible && (
        <div
          className={`fixed inset-x-0 bottom-6 z-[70] mx-auto w-[calc(100%-32px)] max-w-[488px] ${
            toastClosing
              ? "animate-[toast-out_280ms_ease-in]"
              : "animate-[toast-in_280ms_ease-out]"
          }`}
          role="status"
          aria-live="polite"
        >
          <div className="flex items-center gap-3 rounded-2xl bg-[#101a35] px-4 py-3.5 text-white shadow-[0_16px_40px_rgba(16,26,53,0.22)]">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-white/10 text-[#9ebaff]">
              <CircleHelp className="size-5" strokeWidth={1.8} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">این قسمت در حال توسعه است</p>
              <p className="mt-0.5 text-[11px] text-white/60">
                به‌زودی در دسترس خواهد بود
              </p>
            </div>
            <button
              type="button"
              onClick={closeToast}
              className="rounded-lg px-2 py-1 text-xs text-white/60 hover:text-white"
            >
              بستن
            </button>
          </div>
        </div>
      )}

      {menuOpen && (
        <>
          <button
            type="button"
            aria-label="بستن منو"
            onClick={closeMenu}
            className={`fixed inset-0 z-40 bg-[#101a35]/30 backdrop-blur-[2px] ${
              menuClosing
                ? "animate-[overlay-out_260ms_ease-in]"
                : "animate-[overlay-in_260ms_ease-out]"
            }`}
          />
          <aside
            dir="rtl"
            onClick={(event) => event.stopPropagation()}
            className={`fixed inset-y-0 right-0 z-50 w-[78vw] max-w-[350px] overflow-y-auto overscroll-contain bg-white px-5 pb-6 pt-6 shadow-[-18px_0_45px_rgba(16,26,53,0.16)] ${
              menuClosing
                ? "animate-[sidebar-out_260ms_ease-in]"
                : "animate-[sidebar-in_260ms_ease-out]"
            }`}
          >
            <div className="flex items-center justify-between">
              <Link
                href="/"
                onClick={closeMenu}
                className="text-lg font-bold text-[#101a35]"
              >
                MegaStars
              </Link>
              <button
                type="button"
                aria-label="بستن منو"
                onClick={closeMenu}
                onPointerDown={handleCloseRipple}
                className="relative flex size-9 items-center justify-center overflow-hidden rounded-xl text-[#687493] transition-colors hover:bg-[#f3f6ff] hover:text-[#101a35]"
              >
                {closeRipple && (
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute rounded-full bg-[#2f6af4]/15 animate-[ripple_450ms_ease-out]"
                    style={{
                      left: closeRipple.x,
                      top: closeRipple.y,
                      width: closeRipple.size,
                      height: closeRipple.size,
                    }}
                  />
                )}
                <X className="relative z-10 size-5" strokeWidth={1.8} />
              </button>
            </div>

            {currentUser ? (
              <div className="mt-5 flex items-center gap-3 border-b border-[#f0f1f4] pb-5">
                <span className="flex size-10 items-center justify-center rounded-full bg-[#eef1f5] text-[#687493]">
                  <UserRound className="size-5" strokeWidth={1.6} />
                </span>
                <div className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-bold text-[#1d2433]">
                    {currentUser.name}
                  </span>
                  <span className="mt-1 block truncate text-[11px] text-[#8a8f99]">
                    {currentUser.email}
                  </span>
                </div>
                <button
                  type="button"
                  onPointerDown={handleLogoutRipple}
                  onClick={handleLogout}
                  className="relative overflow-hidden rounded-lg px-2 py-1 text-xs font-bold text-[#f06b16]"
                >
                  {logoutRipple && (
                    <span
                      aria-hidden="true"
                      className="pointer-events-none absolute rounded-full bg-[#f06b16]/20 animate-[ripple_450ms_ease-out]"
                      style={{
                        left: logoutRipple.x,
                        top: logoutRipple.y,
                        width: logoutRipple.size,
                        height: logoutRipple.size,
                      }}
                    />
                  )}
                  <span className="relative z-10">خروج</span>
                </button>
              </div>
            ) : (
              <Link
                href="/login"
                onClick={closeMenu}
                className="mt-5 flex items-center gap-3 border-b border-[#f0f1f4] pb-5"
              >
                <span className="flex size-10 items-center justify-center rounded-full bg-[#eef1f5] text-[#687493]">
                  <Bot className="size-6" strokeWidth={1.5} />
                </span>
                <span>
                  <span className="block text-sm text-[#1d2433]">
                    خوش آمدید
                  </span>
                  <span className="mt-1 block text-xs font-bold text-[#f06b16]">
                    ورود به حساب کاربری
                  </span>
                </span>
              </Link>
            )}

            {currentUser && (
              <div className="mt-4 border-b border-[#f0f1f4] pb-4">
                <button
                  type="button"
                  onClick={() => {
                    window.dispatchEvent(new Event("megastars:new-chat"));
                    closeMenu();
                    router.replace("/");
                  }}
                  className="mb-1 flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-xs text-[#242831] transition-colors hover:bg-[#f3f6ff]"
                >
                  <Plus className="size-5 text-[#2f6af4]" strokeWidth={1.9} />
                  چت جدید
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryOpen((value) => !value)}
                  className="flex w-full items-center justify-between rounded-xl px-2 py-2.5 text-xs text-[#242831]"
                >
                  <span className="flex items-center gap-3">
                    <MessageCircle className="size-5" strokeWidth={1.8} />{" "}
                    تاریخچه
                  </span>
                  <ChevronLeft
                    className={`size-4 text-[#9aa0a8] transition-transform duration-200 ease-out ${historyOpen ? "-rotate-90" : ""}`}
                    strokeWidth={1.8}
                  />
                </button>
                <div
                  className={`grid transition-[grid-template-rows,opacity] duration-200 ${historyOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}
                >
                  <div className="min-h-0 overflow-hidden pr-9 pt-1">
                    {chatHistory.length ? (
                      chatHistory.map((chat) => (
                        <div
                          key={chat.publicId}
                          className="flex items-center gap-1 rounded-lg hover:bg-[#f3f6ff]"
                        >
                          <button
                            type="button"
                            onClick={() => {
                              closeMenu();
                              router.push(`/?m=${chat.publicId}`);
                            }}
                            className="min-w-0 flex-1 truncate px-2 py-2 text-right text-[11px] text-[#687493] transition-colors hover:text-[#101a35]"
                          >
                            {chat.title}
                          </button>
                          <button
                            type="button"
                            aria-label="حذف چت"
                            disabled={deletingChat === chat.publicId}
                            onClick={() => void deleteChat(chat.publicId)}
                            className="flex size-7 shrink-0 items-center justify-center rounded-lg text-[#b8beca] transition-colors hover:bg-red-50 hover:text-red-500 disabled:opacity-40"
                          >
                            <Trash2 className="size-3.5" strokeWidth={1.9} />
                          </button>
                        </div>
                      ))
                    ) : (
                      <p className="px-2 py-2 text-right text-[11px] text-[#a5aab5]">
                        هنوز چتی نیست
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="mt-4 space-y-0.5 pt-1">
              <button
                type="button"
                onClick={() => setAssistantsOpen((value) => !value)}
                className="flex w-full items-center justify-between rounded-xl px-2 py-2.5 text-xs text-[#242831]"
              >
                <span className="flex items-center gap-3">
                  <Bot className="size-5" strokeWidth={1.8} /> دستیارها
                </span>
                <ChevronLeft
                  className={`size-4 text-[#9aa0a8] transition-transform duration-200 ease-out ${assistantsOpen ? "-rotate-90" : ""}`}
                  strokeWidth={1.8}
                />
              </button>
              <div
                className={`grid transition-[grid-template-rows,opacity] duration-200 ${assistantsOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}
              >
                <div className="min-h-0 overflow-hidden pr-9">
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]"
                  >
                    تحقیق
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]"
                  >
                    کارشناس کدنویسی
                  </button>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setToolsOpen((value) => !value)}
                className="flex w-full items-center justify-between rounded-xl px-2 py-2.5 text-xs text-[#242831]"
              >
                <span className="flex items-center gap-3">
                  <Wrench className="size-5" strokeWidth={1.8} /> ابزارها
                </span>
                <ChevronLeft
                  className={`size-4 text-[#9aa0a8] transition-transform duration-200 ease-out ${toolsOpen ? "-rotate-90" : ""}`}
                  strokeWidth={1.8}
                />
              </button>
              <div
                className={`grid transition-[grid-template-rows,opacity] duration-200 ${toolsOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}
              >
                <div className="min-h-0 overflow-hidden pr-9">
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]"
                  >
                    حل ریاضیات
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]"
                  >
                    جستجو در اینترنت
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]"
                  >
                    تحلیل کد
                  </button>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => window.dispatchEvent(new Event("megastars:toast"))}
              className="mt-4 w-full rounded-xl bg-[#101010] px-3 py-2.5 text-center text-xs font-bold text-white active:scale-[0.99]"
            >
              <Sparkles className="mr-1 inline size-4 text-[#f06b16]" /> خرید
              اعتبار
            </button>

            <div className="mt-5 space-y-0.5 border-t border-[#f0f1f4] pt-4">
              {[
                [Headphones, "پشتیبانی"],
                [Smartphone, "دانلود اپلیکیشن"],
                [MessageCircle, "آموزش و مقالات"],
                [Settings, "تنظیمات"],
              ].map(([Icon, label]) => (
                <button
                  key={label as string}
                  type="button"
                  className="flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-xs text-[#242831]"
                >
                  <Icon className="size-5" strokeWidth={1.8} />{" "}
                  {label as string}
                </button>
              ))}
            </div>
          </aside>
        </>
      )}
    </>
  );
}
