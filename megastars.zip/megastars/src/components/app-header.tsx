"use client";

import Link from "next/link";
import {
  AudioLines,
  Bell,
  Bot,
  ChevronLeft,
  CircleHelp,
  Headphones,
  Menu,
  MessageCircle,
  Paperclip,
  Settings,
  Smartphone,
  Sparkles,
  Wrench,
  UserRound,
  X,
} from "lucide-react";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export function AppHeader() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuClosing, setMenuClosing] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastClosing, setToastClosing] = useState(false);
  const [closeRipple, setCloseRipple] = useState<{ x: number; y: number; size: number } | null>(null);
  const [currentUser, setCurrentUser] = useState<{ name: string; email: string } | null>(null);
  const [logoutRipple, setLogoutRipple] = useState<{ x: number; y: number; size: number } | null>(null);
  const [assistantsOpen, setAssistantsOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    fetch("/api/auth/me")
      .then((response) => response.json())
      .then((data) => setCurrentUser(data.user))
      .catch(() => setCurrentUser(null));
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  useEffect(() => {
    if (!toastVisible) return;
    const timer = window.setTimeout(() => closeToast(), 3200);
    return () => window.clearTimeout(timer);
  }, [toastVisible]);

  function openMenu() {
    setMenuClosing(false);
    setMenuOpen(true);
  }

  function handleLogoutRipple(event: React.PointerEvent<HTMLButtonElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2.2;
    setLogoutRipple({
      x: event.clientX - rect.left - size / 2,
      y: event.clientY - rect.top - size / 2,
      size,
    });
    window.setTimeout(() => setLogoutRipple(null), 450);
  }

  async function handleLogout() {
    closeMenu();
    await new Promise((resolve) => window.setTimeout(resolve, 280));
    await fetch("/api/auth/logout", { method: "POST" });
    setCurrentUser(null);
    router.refresh();
  }

  function handleCloseRipple(event: React.PointerEvent<HTMLButtonElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2.2;
    setCloseRipple({
      x: event.clientX - rect.left - size / 2,
      y: event.clientY - rect.top - size / 2,
      size,
    });
    window.setTimeout(() => setCloseRipple(null), 450);
  }

  function closeMenu() {
    setMenuClosing(true);
    window.setTimeout(() => {
      setMenuOpen(false);
      setMenuClosing(false);
    }, 260);
  }

  function openToast() {
    setToastClosing(false);
    setToastVisible(true);
  }

  function closeToast() {
    setToastClosing(true);
    window.setTimeout(() => {
      setToastVisible(false);
      setToastClosing(false);
    }, 280);
  }

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-30 mx-auto flex h-20 w-full items-center justify-between bg-transparent px-5 sm:px-7">
        <button
          type="button"
          aria-label="باز کردن منو"
          onClick={openMenu}
          className="flex size-11 items-center justify-center rounded-2xl border border-[#edf0f6] bg-white text-[#1f376d] shadow-[0_6px_18px_rgba(45,74,130,0.06)] transition-transform active:scale-95"
        >
          <Menu className="size-[22px]" strokeWidth={1.8} />
        </button>

        <button
          type="button"
          aria-label="اعلان‌ها"
          onClick={openToast}
          className="relative flex size-11 items-center justify-center rounded-2xl border border-[#edf0f6] bg-white text-[#1f376d] shadow-[0_6px_18px_rgba(45,74,130,0.06)] transition-transform active:scale-95"
        >
          <Bell className="size-[21px]" strokeWidth={1.8} />
        </button>
      </header>

      {toastVisible && (
        <div
          className={`fixed inset-x-0 bottom-6 z-[70] mx-auto w-[calc(100%-32px)] max-w-[488px] ${
            toastClosing ? "animate-[toast-out_280ms_ease-in]" : "animate-[toast-in_280ms_ease-out]"
          }`}
          role="status"
          aria-live="polite"
        >
          <div className="flex items-center gap-3 rounded-2xl bg-[#101a35] px-4 py-3.5 text-white shadow-[0_16px_40px_rgba(16,26,53,0.22)]">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-white/10 text-[#9ebaff]">
              <CircleHelp className="size-5" strokeWidth={1.8} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">این قسمت در حال توسعه است</p>
              <p className="mt-0.5 text-[11px] text-white/60">به‌زودی در دسترس خواهد بود</p>
            </div>
            <button type="button" onClick={closeToast} className="rounded-lg px-2 py-1 text-xs text-white/60 hover:text-white">
              بستن
            </button>
          </div>
        </div>
      )}

      {menuOpen && (
        <>
          <button
            type="button"
            aria-label="بستن منو"
            onClick={closeMenu}
            className={`fixed inset-0 z-40 bg-[#101a35]/30 backdrop-blur-[2px] ${
              menuClosing ? "animate-[overlay-out_260ms_ease-in]" : "animate-[overlay-in_260ms_ease-out]"
            }`}
          />
          <aside
            dir="rtl"
            onClick={(event) => event.stopPropagation()}
            className={`fixed inset-y-0 right-0 z-50 w-[78vw] max-w-[350px] overflow-y-auto overscroll-contain bg-white px-5 pb-6 pt-6 shadow-[-18px_0_45px_rgba(16,26,53,0.16)] ${
              menuClosing ? "animate-[sidebar-out_260ms_ease-in]" : "animate-[sidebar-in_260ms_ease-out]"
            }`}
          >
            <div className="flex items-center justify-between">
              <Link href="/" onClick={closeMenu} className="text-lg font-bold text-[#101a35]">
                MegaStars
              </Link>
              <button
                type="button"
                aria-label="بستن منو"
                onClick={closeMenu}
                onPointerDown={handleCloseRipple}
                className="relative flex size-9 items-center justify-center overflow-hidden rounded-xl text-[#687493] transition-colors hover:bg-[#f3f6ff] hover:text-[#101a35]"
              >
                {closeRipple && (
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute rounded-full bg-[#2f6af4]/15 animate-[ripple_450ms_ease-out]"
                    style={{ left: closeRipple.x, top: closeRipple.y, width: closeRipple.size, height: closeRipple.size }}
                  />
                )}
                <X className="relative z-10 size-5" strokeWidth={1.8} />
              </button>
            </div>

            {currentUser ? (
              <div className="mt-5 flex items-center gap-3 border-b border-[#f0f1f4] pb-5">
                <span className="flex size-10 items-center justify-center rounded-full bg-[#eef1f5] text-[#687493]"><UserRound className="size-5" strokeWidth={1.6} /></span>
                <div className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-bold text-[#1d2433]">{currentUser.name}</span>
                  <span className="mt-1 block truncate text-[11px] text-[#8a8f99]">{currentUser.email}</span>
                </div>
                <button
                  type="button"
                  onPointerDown={handleLogoutRipple}
                  onClick={handleLogout}
                  className="relative overflow-hidden rounded-lg px-2 py-1 text-xs font-bold text-[#f06b16]"
                >
                  {logoutRipple && (
                    <span
                      aria-hidden="true"
                      className="pointer-events-none absolute rounded-full bg-[#f06b16]/20 animate-[ripple_450ms_ease-out]"
                      style={{ left: logoutRipple.x, top: logoutRipple.y, width: logoutRipple.size, height: logoutRipple.size }}
                    />
                  )}
                  <span className="relative z-10">خروج</span>
                </button>
              </div>
            ) : (
              <Link href="/login" onClick={closeMenu} className="mt-5 flex items-center gap-3 border-b border-[#f0f1f4] pb-5">
                <span className="flex size-10 items-center justify-center rounded-full bg-[#eef1f5] text-[#687493]"><Bot className="size-6" strokeWidth={1.5} /></span>
                <span>
                  <span className="block text-sm text-[#1d2433]">خوش آمدید</span>
                  <span className="mt-1 block text-xs font-bold text-[#f06b16]">ورود به حساب کاربری</span>
                </span>
              </Link>
            )}

            <div className="mt-4 space-y-0.5 pt-1">
              <button type="button" onClick={() => setAssistantsOpen((value) => !value)} className="flex w-full items-center justify-between rounded-xl px-2 py-2.5 text-xs text-[#242831]">
                <span className="flex items-center gap-3"><Bot className="size-5" strokeWidth={1.8} /> دستیارها</span>
                <ChevronLeft
                  className={`size-4 text-[#9aa0a8] transition-transform duration-200 ease-out ${assistantsOpen ? "-rotate-90" : ""}`}
                  strokeWidth={1.8}
                />
              </button>
              <div className={`grid transition-[grid-template-rows,opacity] duration-200 ${assistantsOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}>
                <div className="min-h-0 overflow-hidden pr-9">
                  <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]">تحقیق</button>
                  <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]">کارشناس کدنویسی</button>
                </div>
              </div>
              <button type="button" onClick={() => setToolsOpen((value) => !value)} className="flex w-full items-center justify-between rounded-xl px-2 py-2.5 text-xs text-[#242831]">
                <span className="flex items-center gap-3"><Wrench className="size-5" strokeWidth={1.8} /> ابزارها</span>
                <ChevronLeft className={`size-4 text-[#9aa0a8] transition-transform duration-200 ease-out ${toolsOpen ? "-rotate-90" : ""}`} strokeWidth={1.8} />
              </button>
              <div className={`grid transition-[grid-template-rows,opacity] duration-200 ${toolsOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}>
                <div className="min-h-0 overflow-hidden pr-9">
                  <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]">حل ریاضیات</button>
                  <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]">جستجو در اینترنت</button>
                  <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="block w-full rounded-lg px-2 py-2 text-right text-[11px] text-[#687493]">تحلیل کد</button>
                </div>
              </div>
              {[
                [AudioLines, "صداگذاری و دوبله"],
                [Paperclip, "کانال پرامپت"],
              ].map(([Icon, label]) => (
                <button key={label as string} type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="flex w-full items-center justify-between rounded-xl px-2 py-2.5 text-xs text-[#242831]">
                  <span className="flex items-center gap-3"><Icon className="size-5" strokeWidth={1.8} /> {label as string}</span>
                  <ChevronLeft className="size-4 text-[#9aa0a8]" strokeWidth={1.8} />
                </button>
              ))}
            </div>

            <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="mt-4 w-full rounded-xl bg-[#101010] px-3 py-2.5 text-center text-xs font-bold text-white active:scale-[0.99]">
              <Sparkles className="mr-1 inline size-4 text-[#f06b16]" /> خرید اعتبار
            </button>

            <div className="mt-5 space-y-0.5 border-t border-[#f0f1f4] pt-4">
              {[
                [Headphones, "پشتیبانی"],
                [Smartphone, "دانلود اپلیکیشن"],
                [MessageCircle, "آموزش و مقالات"],
                [Settings, "تنظیمات"],
              ].map(([Icon, label]) => (
                <button key={label as string} type="button" className="flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-xs text-[#242831]">
                  <Icon className="size-5" strokeWidth={1.8} /> {label as string}
                </button>
              ))}
            </div>
          </aside>
        </>
      )}
    </>
  );
}
