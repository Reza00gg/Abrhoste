"use client";

import { usePathname, useRouter } from "next/navigation";
import { BarChart3, ChevronLeft, LogOut, Menu, Settings, ShieldCheck, SlidersHorizontal, Smartphone, Users, X } from "lucide-react";
import { useEffect, useState } from "react";
import { AdminRippleButton } from "@/components/admin/admin-ripple-button";

const adminPath = "/adminChash7nakg";
const securityPath = `${adminPath}/security`;
const devicesPath = `${securityPath}/devices`;
const items = [
  { label: "داشبورد", href: adminPath, icon: BarChart3 },
  { label: "کاربران", href: `${adminPath}/users`, icon: Users },
  { label: "مدل‌ها", href: `${adminPath}/models`, icon: SlidersHorizontal },
  { label: "تنظیمات", href: `${adminPath}/settings`, icon: Settings },
];


export function AdminShell({ children, adminName }: { children: React.ReactNode; adminName: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [securityOpen, setSecurityOpen] = useState(() => pathname.startsWith(securityPath));
  const securityActive = pathname.startsWith(securityPath);

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  useEffect(() => {
    let active = true;
    async function verifyAdminSession() {
      const response = await fetch("/api/admin/session", { cache: "no-store" });
      if (active && !response.ok) {
        router.replace(adminPath);
        router.refresh();
      }
    }
    const timer = window.setInterval(verifyAdminSession, 7000);
    window.addEventListener("focus", verifyAdminSession);
    return () => {
      active = false;
      window.clearInterval(timer);
      window.removeEventListener("focus", verifyAdminSession);
    };
  }, [router]);

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.replace(adminPath);
    router.refresh();
  }

  return (
    <div dir="rtl" className="min-h-dvh bg-[#09090b] text-white">
      <header className="fixed inset-x-0 top-0 z-30 h-16 border-b border-white/10 bg-[#09090b]/95 backdrop-blur-xl">
        <div className="mx-auto flex h-full max-w-[1180px] items-center justify-between px-5">
          <AdminRippleButton onClick={() => setOpen(true)} className="rounded-xl p-2 text-white/60 transition-colors hover:bg-white/5 hover:text-white lg:hidden"><Menu className="size-5" strokeWidth={1.9} /></AdminRippleButton>
          <h1 className="text-sm font-bold">پنل مدیریت</h1>
          <AdminRippleButton onClick={logout} className="rounded-xl p-2 text-white/60 transition-colors hover:bg-white/5 hover:text-[#f06b16]"><LogOut className="size-5" strokeWidth={1.9} absoluteStrokeWidth shapeRendering="geometricPrecision" /></AdminRippleButton>
        </div>
      </header>
      {open && <button aria-label="بستن منو" onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-black/60 lg:hidden" />}
      <aside className={`fixed inset-y-0 right-0 z-50 w-[244px] overflow-hidden border-l border-white/10 bg-[#111114] px-3 pb-5 pt-4 shadow-[-12px_0_35px_rgba(0,0,0,0.22)] transition-transform duration-200 ease-out lg:translate-x-0 ${open ? "translate-x-0" : "translate-x-full"}`}>
        <div className="mb-4 flex items-start justify-between gap-3"><div className="min-w-0 pt-0.5"><p className="text-xs text-white/40">خوش آمدید</p><p className="mt-1 truncate text-sm font-bold">{adminName}</p></div><AdminRippleButton onClick={() => setOpen(false)} className="rounded-xl p-2 text-white/45 transition-colors hover:bg-white/5 hover:text-white lg:hidden"><X className="size-5" strokeWidth={1.9} absoluteStrokeWidth shapeRendering="geometricPrecision" /></AdminRippleButton></div>
        <nav className="space-y-1">
          {items.map(({ label, href, icon: Icon }) => <AdminRippleButton key={href} onClick={() => { setOpen(false); router.push(href); }} className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-xs transition-colors ${pathname === href ? "bg-[#f06b16] text-white" : "text-white/55 hover:bg-white/5 hover:text-white"}`}><Icon className="size-[17px]" strokeWidth={1.9} />{label}</AdminRippleButton>)}
          <AdminRippleButton onClick={() => setSecurityOpen((value) => !value)} className={`flex w-full items-center justify-between rounded-xl py-2.5 pr-3 pl-1.5 text-xs transition-colors [&>span]:w-full [&>span]:justify-between ${securityActive ? "bg-white/[0.08] text-white" : "text-white/55 hover:bg-white/5 hover:text-white"}`}>
            <span className="flex items-center gap-2.5"><ShieldCheck className="size-[17px]" strokeWidth={1.9} />امنیت</span>
            <ChevronLeft className={`size-4 text-white/35 transition-transform duration-200 ease-out ${securityOpen ? "-rotate-90" : ""}`} strokeWidth={1.9} />
          </AdminRippleButton>
          <div className={`grid transition-[grid-template-rows,opacity] duration-200 ease-out ${securityOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}>
            <div className="min-h-0 overflow-hidden pr-7">
              <AdminRippleButton onClick={() => { setOpen(false); router.push(devicesPath); }} className={`mt-1 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-[11px] transition-colors ${pathname === devicesPath ? "bg-[#f06b16] text-white" : "text-white/45 hover:bg-white/5 hover:text-white"}`}><Smartphone className="size-4" strokeWidth={1.8} />دستگاه‌ها</AdminRippleButton>
            </div>
          </div>
        </nav>
        <div className="absolute bottom-6 right-5 left-5 border-t border-white/10 pt-4 text-[11px] text-white/30">MegaStars Admin • فاز اول</div>
      </aside>
      <main className="mx-auto max-w-[1180px] px-4 pb-8 pt-20 lg:mr-72">{children}</main>
    </div>
  );
}
