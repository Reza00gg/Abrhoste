"use client";

import { usePathname, useRouter } from "next/navigation";
import { BarChart3, LogOut, Menu, Settings, SlidersHorizontal, Users, X } from "lucide-react";
import { useState } from "react";
import { AdminRippleButton } from "@/components/admin/admin-ripple-button";

const adminPath = "/adminChash7nakg";
const items = [
  { label: "داشبورد", href: adminPath, icon: BarChart3 },
  { label: "کاربران", href: `${adminPath}/users`, icon: Users },
  { label: "مدل‌ها", href: `${adminPath}/models`, icon: SlidersHorizontal },
  { label: "تنظیمات", href: `${adminPath}/settings`, icon: Settings },
];

export function AdminShell({ children, adminName }: { children: React.ReactNode; adminName: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.replace(adminPath);
    router.refresh();
  }

  return (
    <div dir="rtl" className="min-h-dvh bg-[#09090b] text-white">
      <header className="fixed inset-x-0 top-0 z-30 h-16 border-b border-white/10 bg-[#09090b]/95 backdrop-blur-xl">
        <div className="mx-auto flex h-full max-w-[1180px] items-center justify-between px-5">
          <AdminRippleButton onClick={() => setOpen(true)} className="rounded-xl p-2 text-white/60 hover:bg-white/5 lg:hidden"><Menu className="size-5" /></AdminRippleButton>
          <h1 className="text-sm font-bold">پنل مدیریت</h1>
          <AdminRippleButton onClick={logout} className="rounded-xl p-2 text-white/60 hover:bg-white/5"><LogOut className="size-5" /></AdminRippleButton>
        </div>
      </header>
      {open && <button aria-label="بستن منو" onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-black/60 lg:hidden" />}
      <aside className={`fixed inset-y-0 right-0 z-50 w-[248px] border-l border-white/10 bg-[#111114] p-3 pt-12 shadow-[-12px_0_35px_rgba(0,0,0,0.22)] transition-transform lg:translate-x-0 ${open ? "translate-x-0" : "translate-x-full"}`}>
        <div className="mb-3 flex items-center justify-between"><div><p className="text-xs text-white/40">خوش آمدید</p><p className="mt-1 text-sm font-bold">{adminName}</p></div><button onClick={() => setOpen(false)} className="rounded-lg p-2 text-white/40 lg:hidden"><X className="size-5" /></button></div>
        <nav className="space-y-1">
          {items.map(({ label, href, icon: Icon }) => <AdminRippleButton key={href} onClick={() => { setOpen(false); router.push(href); }} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs transition-colors ${pathname === href ? "bg-[#f06b16] text-white" : "text-white/55 hover:bg-white/5 hover:text-white"}`}><Icon className="size-4" />{label}</AdminRippleButton>)}
        </nav>
        <div className="absolute bottom-6 right-5 left-5 border-t border-white/10 pt-4 text-[11px] text-white/30">MegaStars Admin • فاز اول</div>
      </aside>
      <main className="mx-auto max-w-[1180px] px-4 pb-8 pt-20 lg:mr-72">{children}</main>
    </div>
  );
}
