"use client";

import { CSSProperties, PointerEvent, ReactNode, useState } from "react";

type Ripple = { x: number; y: number; size: number };

export function AdminRippleButton({ children, className = "", onClick, type = "button", disabled = false }: { children: ReactNode; className?: string; onClick?: () => void; type?: "button" | "submit"; disabled?: boolean }) {
  const [ripple, setRipple] = useState<Ripple | null>(null);
  function pointerDown(event: PointerEvent<HTMLButtonElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2;
    setRipple({ x: event.clientX - rect.left - size / 2, y: event.clientY - rect.top - size / 2, size });
    window.setTimeout(() => setRipple(null), 430);
  }
  const style = ripple ? ({ left: ripple.x, top: ripple.y, width: ripple.size, height: ripple.size } as CSSProperties) : undefined;
  return <button type={type} disabled={disabled} onPointerDown={pointerDown} onClick={onClick} className={`relative overflow-hidden ${className}`}>
    {ripple && <span aria-hidden="true" style={style} className="pointer-events-none absolute rounded-full bg-white/15 animate-[ripple_430ms_ease-out]" />}
    <span className="relative z-10 flex items-center gap-[inherit]">{children}</span>
  </button>;
}
