"use client";

import { useEffect, useRef, useState } from "react";
import { CheckCircle2, MoreVertical, RefreshCw, Search, Trash2, UserRound, XCircle } from "lucide-react";
import { AdminRippleButton } from "@/components/admin/admin-ripple-button";

type User = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  status: string;
  role: string;
  deletedAt: Date | null;
  createdAt: Date;
  lastLoginAt: Date | null;
};
type Tab = "all" | "active" | "inactive" | "deleted";

export function UserList({ initialUsers, initialTotal }: { initialUsers: User[]; initialTotal: number }) {
  const [users, setUsers] = useState(initialUsers);
  const [menu, setMenu] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("all");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [totalUsers, setTotalUsers] = useState(initialTotal);
  const [loading, setLoading] = useState(false);
  const [counts, setCounts] = useState({ all: initialTotal, active: 0, inactive: 0, deleted: 0 });
  const firstLoad = useRef(true);

  async function fetchPage(nextPage: number, nextTab = tab, nextSearch = query, showLoading = false) {
    if (showLoading) setLoading(true);
    const response = await fetch(`/api/admin/users?page=${nextPage}&tab=${nextTab}&search=${encodeURIComponent(nextSearch)}`);
    if (response.ok) {
      const data = await response.json();
      setUsers(data.items);
      setTotalUsers(data.total);
      setCounts(data.counts);
      setPage(nextPage);
    }
    if (showLoading) setLoading(false);
  }

  useEffect(() => {
    const timer = window.setTimeout(() => {
      fetchPage(1, tab, query, firstLoad.current);
      firstLoad.current = false;
    }, 220);
    return () => window.clearTimeout(timer);
  // Fetch only after the user pauses typing; the current tab is part of the request.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  useEffect(() => {
    if (!menu) return;
    function closeFromOutside(event: MouseEvent) {
      if (!(event.target as HTMLElement).closest("[data-user-menu]")) setMenu(null);
    }
    document.addEventListener("mousedown", closeFromOutside);
    return () => document.removeEventListener("mousedown", closeFromOutside);
  }, [menu]);

  async function updateUser(id: string, action: "active" | "inactive" | "delete" | "reset" | "permanent-delete") {
    const response = action === "delete" || action === "permanent-delete"
      ? await fetch(`/api/admin/users/${id}${action === "permanent-delete" ? "?permanent=1" : ""}`, { method: "DELETE" })
      : action === "reset"
        ? await fetch(`/api/admin/users/${id}/reset`, { method: "POST" })
        : await fetch(`/api/admin/users/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: action }),
          });
    if (!response.ok) {
      setMessage("عملیات انجام نشد.");
      return;
    }
    setUsers((current) => current.map((user) => user.id === id
      ? { ...user, status: action === "delete" ? "inactive" : action === "active" ? "active" : user.status, deletedAt: action === "delete" ? new Date() : action === "active" ? null : user.deletedAt }
      : user));
    setMenu(null);
    const messages = { active: "کاربر فعال شد.", inactive: "کاربر غیرفعال شد.", delete: "کاربر حذف شد.", reset: "اطلاعات کاربر ریست شد.", "permanent-delete": "کاربر برای همیشه حذف شد." };
    setMessage(messages[action]);
    window.setTimeout(() => setMessage(null), 2200);
  }

  const filteredUsers = users.filter((user) => {
    return `${user.name} ${user.email}`.toLowerCase().includes(query.toLowerCase());
  });

  const tabs: [Tab, string, number][] = [["all", "کاربران", counts.all], ["active", "فعال", counts.active], ["inactive", "غیرفعال", counts.inactive], ["deleted", "حذف‌شده", counts.deleted]];

  return (
    <section>
      {message && <div className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-xl bg-[#151518] px-4 py-3 text-xs text-white shadow-2xl"><CheckCircle2 className="size-4 text-emerald-400" />{message}</div>}
      <div className="mb-4 grid grid-cols-4 overflow-hidden rounded-xl border border-[#1f1f1f] bg-[#0a0a0a] p-1 text-[11px] text-white/45">
        {tabs.map(([value, label, count]) => <AdminRippleButton key={value} onClick={() => { setTab(value); fetchPage(1, value, query, false); }} className={`flex h-9 items-center justify-center gap-1.5 rounded-lg px-1 font-medium transition-colors ${tab === value ? "bg-[#18181b] text-white" : "hover:text-white"}`}>{label}<span className="rounded-full bg-[#27272a] px-1.5 py-0.5 text-[10px] text-[#a1a1aa]">{count}</span></AdminRippleButton>)}
      </div>
      <label className="relative mb-4 block"><Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-white/35" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="جستجو..." className="h-10 w-full rounded-lg border border-[#1f1f1f] bg-[#0a0a0a] px-10 text-right text-xs text-white outline-none placeholder:text-white/25 transition-[border-color,box-shadow] duration-300 ease-out focus:border-[#f06b16] focus:shadow-[0_0_0_3px_rgba(240,107,22,0.12)]" /></label>
      {loading ? <div className="flex min-h-48 items-center justify-center"><div className="size-6 animate-spin rounded-full border-2 border-white/15 border-t-[#f06b16]" /></div> : <div className="space-y-2">
        {filteredUsers.map((user) => <article key={user.id} className="relative rounded-xl border border-[#1f1f1f] bg-[#18181b] p-3.5">
          <div className="flex items-center gap-3.5">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-full border border-[#1f1f1f] bg-[#0a0a0a] text-white/35"><UserRound className="size-[18px]" /></span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2"><h3 className="truncate text-[13px] font-semibold text-white">{user.name}</h3><span className={`rounded px-1.5 py-0.5 text-[10px] ${user.deletedAt ? "bg-red-500/15 text-red-400" : user.status === "active" ? "bg-green-500/15 text-green-400" : "bg-amber-500/15 text-amber-400"}`}>{user.deletedAt ? "حذف‌شده" : user.status === "active" ? "فعال" : "غیرفعال"}</span></div>
              <p dir="ltr" className="truncate text-[11px] text-white/40">{user.email}</p>
              <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[10px] text-white/25"><span>عضو از {new Date(user.createdAt).toLocaleDateString("fa-IR")}</span><span className="rounded-full bg-[#27272a] px-1.5 py-0.5">بدون اشتراک</span></div>
            </div>
            <div data-user-menu className="relative shrink-0">
              <AdminRippleButton onClick={() => setMenu(menu === user.id ? null : user.id)} className="rounded-lg p-2 text-white/45 hover:bg-white/5"><MoreVertical className="size-5" /></AdminRippleButton>
              {menu === user.id && <div className="absolute left-0 top-10 z-20 w-36 animate-[admin-menu-in_160ms_ease-out] rounded-2xl border border-white/10 bg-[#09090b] p-2 shadow-xl">
                {user.deletedAt ? <>
                  <AdminRippleButton onClick={() => updateUser(user.id, "active")} className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-[10px] text-green-300 hover:bg-white/5"><CheckCircle2 className="size-3.5" />بازیابی</AdminRippleButton>
                  <AdminRippleButton onClick={() => updateUser(user.id, "permanent-delete")} className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-[10px] text-red-300 hover:bg-white/5"><Trash2 className="size-3.5" />حذف دائمی</AdminRippleButton>
                </> : <>
                  {user.status === "active" ? <AdminRippleButton onClick={() => updateUser(user.id, "inactive")} className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-[10px] text-amber-300 hover:bg-white/5"><XCircle className="size-3.5" />غیرفعال کردن</AdminRippleButton> : <AdminRippleButton onClick={() => updateUser(user.id, "active")} className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-[10px] text-green-300 hover:bg-white/5"><CheckCircle2 className="size-3.5" />فعال کردن</AdminRippleButton>}
                  <AdminRippleButton onClick={() => updateUser(user.id, "reset")} className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-[10px] text-blue-300 hover:bg-white/5"><RefreshCw className="size-3.5" />ریست اطلاعات</AdminRippleButton>
                  <AdminRippleButton onClick={() => updateUser(user.id, "delete")} className="flex w-full items-center gap-2 rounded-lg px-1.5 py-1 text-[10px] text-red-300 hover:bg-white/5"><Trash2 className="size-3.5" />حذف</AdminRippleButton>
                </>}
              </div>}
            </div>
          </div>
        </article>)}
      </div>}
      {filteredUsers.length === 0 && !loading && <div className="py-12 text-center text-sm text-white/35">نتیجه‌ای یافت نشد</div>}
      {Math.ceil(totalUsers / 8) > 1 && <div className="mt-5 flex items-center justify-center gap-2 text-xs text-white/40">
        <AdminRippleButton onClick={() => fetchPage(page - 1)} className="rounded-lg bg-[#18181b] px-3 py-2 disabled:opacity-30" disabled={page === 1}>قبلی</AdminRippleButton>
        <span>صفحه {page} از {Math.ceil(totalUsers / 8)}</span>
        <AdminRippleButton onClick={() => fetchPage(page + 1)} className="rounded-lg bg-[#18181b] px-3 py-2 disabled:opacity-30" disabled={page >= Math.ceil(totalUsers / 8)}>بعدی</AdminRippleButton>
      </div>}
    </section>
  );
}
