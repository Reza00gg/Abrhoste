"use client";

import { useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  Ban,
  CheckCircle2,
  MoreVertical,
  RotateCcw,
  Search,
  Trash2,
  UserRound,
} from "lucide-react";
import { AdminRippleButton } from "@/components/admin/admin-ripple-button";

type User = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  status: string;
  role: string;
  deletedAt: Date | null;
  createdAt: Date;
  lastLoginAt: Date | null;
};
type Tab = "all" | "active" | "inactive" | "deleted";
type Toast = { message: string; tone: "success" | "error" };
type UsersPayload = {
  items: User[];
  total: number;
  counts: Record<Tab, number>;
  page: number;
  totalPages: number;
};

const PAGE_SIZE = 8;
const usersCache = new Map<string, UsersPayload>();
const usersStore: {
  lastView: { tab: Tab; query: string; data: UsersPayload } | null;
} = { lastView: null };

function rememberUsersView(tab: Tab, query: string, data: UsersPayload) {
  usersStore.lastView = { tab, query, data };
}

function clearUsersMemory() {
  usersCache.clear();
  usersStore.lastView = null;
}

export function UserList({
  initialUsers,
  initialTotal,
}: {
  initialUsers: User[];
  initialTotal: number;
}) {
  const cachedView = usersStore.lastView;
  const restoredFromCache = useRef(Boolean(cachedView));
  const [users, setUsers] = useState(
    () => cachedView?.data.items ?? initialUsers,
  );
  const [menu, setMenu] = useState<string | null>(null);
  const [closingMenu, setClosingMenu] = useState<string | null>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const [toastClosing, setToastClosing] = useState(false);
  const [tab, setTab] = useState<Tab>(() => cachedView?.tab ?? "all");
  const [query, setQuery] = useState(() => cachedView?.query ?? "");
  const [page, setPage] = useState(() => cachedView?.data.page ?? 1);
  const [totalUsers, setTotalUsers] = useState(
    () => cachedView?.data.total ?? initialTotal,
  );
  const [loading, setLoading] = useState(() => !cachedView);
  const [counts, setCounts] = useState<Record<Tab, number>>(
    () =>
      cachedView?.data.counts ?? {
        all: initialTotal,
        active: 0,
        inactive: 0,
        deleted: 0,
      },
  );
  const toastTimer = useRef<number | null>(null);
  const toastCloseTimer = useRef<number | null>(null);
  const menuTimer = useRef<number | null>(null);

  function cacheKey(nextPage: number, nextTab: Tab, nextSearch: string) {
    return `${nextTab}:${nextPage}:${nextSearch.trim().toLowerCase()}`;
  }

  function applyUsersPayload(data: UsersPayload) {
    setUsers(data.items);
    setTotalUsers(data.total);
    setCounts(data.counts);
    setPage(data.page);
  }

  function closeToast() {
    if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
    setToastClosing(true);
    toastCloseTimer.current = window.setTimeout(() => {
      setToast(null);
      setToastClosing(false);
    }, 220);
  }

  function showToast(message: string, tone: Toast["tone"] = "success") {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
    setToastClosing(false);
    setToast({ message, tone });
    toastTimer.current = window.setTimeout(() => closeToast(), 2600);
  }

  function closeUserMenu() {
    if (!menu || closingMenu) return;
    if (menuTimer.current) window.clearTimeout(menuTimer.current);
    setClosingMenu(menu);
    menuTimer.current = window.setTimeout(() => {
      setMenu(null);
      setClosingMenu(null);
    }, 160);
  }

  function toggleUserMenu(id: string) {
    if (menuTimer.current) window.clearTimeout(menuTimer.current);
    if (menu === id && !closingMenu) {
      closeUserMenu();
      return;
    }
    setClosingMenu(null);
    setMenu(id);
  }

  async function fetchPage(
    nextPage: number,
    nextTab = tab,
    nextSearch = query,
    showLoading = true,
    force = false,
  ) {
    const key = cacheKey(nextPage, nextTab, nextSearch);
    const cached = force ? undefined : usersCache.get(key);
    if (cached) {
      rememberUsersView(nextTab, nextSearch, cached);
      applyUsersPayload(cached);
      setLoading(false);
      return;
    }

    if (showLoading) setLoading(true);
    try {
      const response = await fetch(
        `/api/admin/users?page=${nextPage}&tab=${nextTab}&search=${encodeURIComponent(nextSearch)}`,
      );
      if (!response.ok) {
        showToast("دریافت لیست کاربران انجام نشد.", "error");
        return;
      }
      const data = (await response.json()) as UsersPayload;
      usersCache.set(key, data);
      rememberUsersView(nextTab, nextSearch, data);
      applyUsersPayload(data);
    } catch {
      showToast("ارتباط با سرور برای دریافت کاربران برقرار نشد.", "error");
    } finally {
      if (showLoading) setLoading(false);
    }
  }

  useEffect(() => {
    return () => {
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
      if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
      if (menuTimer.current) window.clearTimeout(menuTimer.current);
    };
  }, []);

  useEffect(() => {
    if (restoredFromCache.current) {
      restoredFromCache.current = false;
      return;
    }
    const timer = window.setTimeout(() => {
      fetchPage(1, tab, query, true);
    }, 220);
    return () => window.clearTimeout(timer);
    // Fetch only after the user pauses typing; the current tab is part of the request.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  useEffect(() => {
    if (!menu || closingMenu) return;
    function closeFromOutside(event: MouseEvent) {
      if ((event.target as HTMLElement).closest("[data-user-menu]")) return;
      if (menuTimer.current) window.clearTimeout(menuTimer.current);
      setClosingMenu(menu);
      menuTimer.current = window.setTimeout(() => {
        setMenu(null);
        setClosingMenu(null);
      }, 160);
    }
    document.addEventListener("mousedown", closeFromOutside);
    return () => document.removeEventListener("mousedown", closeFromOutside);
  }, [menu, closingMenu]);

  async function updateUser(
    id: string,
    action: "active" | "inactive" | "delete" | "reset" | "permanent-delete",
  ) {
    const successMessages = {
      active: "کاربر فعال شد.",
      inactive: "کاربر غیرفعال شد.",
      delete: "کاربر به لیست حذف‌شده‌ها منتقل شد.",
      reset: "تنظیمات کاربر ریست شد.",
      "permanent-delete": "کاربر برای همیشه حذف شد.",
    };
    const errorMessages = {
      active: "فعال‌سازی کاربر انجام نشد.",
      inactive: "غیرفعال‌سازی کاربر انجام نشد.",
      delete: "حذف کاربر انجام نشد.",
      reset: "ریست تنظیمات کاربر انجام نشد.",
      "permanent-delete": "حذف دائمی کاربر انجام نشد.",
    };

    closeUserMenu();

    try {
      const response =
        action === "delete" || action === "permanent-delete"
          ? await fetch(
              `/api/admin/users/${id}${action === "permanent-delete" ? "?permanent=1" : ""}`,
              { method: "DELETE" },
            )
          : action === "reset"
            ? await fetch(`/api/admin/users/${id}/reset`, { method: "POST" })
            : await fetch(`/api/admin/users/${id}`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ status: action }),
              });

      if (!response.ok) {
        const result = await response.json().catch(() => null);
        showToast(result?.message ?? errorMessages[action], "error");
        return;
      }

      closeUserMenu();
      clearUsersMemory();
      const nextPage =
        action === "permanent-delete" && users.length === 1 && page > 1
          ? page - 1
          : page;
      await fetchPage(nextPage, tab, query, false, true);
      showToast(successMessages[action]);
    } catch {
      showToast(errorMessages[action], "error");
    }
  }

  const displayUsers = users;
  const totalPages = Math.max(1, Math.ceil(totalUsers / PAGE_SIZE));
  const rangeStart = totalUsers === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
  const rangeEnd = Math.min(page * PAGE_SIZE, totalUsers);

  const tabs: [Tab, string, number][] = [
    ["all", "کاربران", counts.all],
    ["active", "فعال", counts.active],
    ["inactive", "غیرفعال", counts.inactive],
    ["deleted", "حذف‌شده", counts.deleted],
  ];

  return (
    <section>
      {toast && (
        <div
          className={`fixed bottom-5 left-1/2 z-50 flex min-w-[250px] max-w-[calc(100vw-32px)] -translate-x-1/2 items-center gap-2.5 rounded-2xl border px-4 py-3.5 text-[13px] font-medium shadow-2xl ${toastClosing ? "animate-[toast-out_220ms_ease-in]" : "animate-[toast-in_220ms_ease-out]"} ${toast.tone === "success" ? "border-emerald-400/15 bg-[#151518] text-white" : "border-red-400/20 bg-[#1b1010] text-red-100"}`}
        >
          {toast.tone === "success" ? (
            <CheckCircle2 className="size-[18px] shrink-0 text-emerald-400" />
          ) : (
            <AlertCircle className="size-[18px] shrink-0 text-red-300" />
          )}
          <span>{toast.message}</span>
        </div>
      )}
      <div className="mb-4 grid grid-cols-4 overflow-hidden rounded-xl border border-[#1f1f1f] bg-[#0a0a0a] p-1 text-[10.5px] text-white/45">
        {tabs.map(([value, label, count]) => (
          <AdminRippleButton
            key={value}
            onClick={() => {
              setTab(value);
              fetchPage(1, value, query, true);
            }}
            className={`flex h-9 items-center justify-center gap-1.5 rounded-lg px-0.5 font-medium transition-colors sm:gap-2 ${tab === value ? "bg-[#18181b] text-white" : "hover:text-white"}`}
          >
            {label}
            <span className="ms-0.5 min-w-[18px] rounded-full bg-[#27272a] px-1.5 py-0.5 text-center text-[10px] text-[#a1a1aa]">
              {count}
            </span>
          </AdminRippleButton>
        ))}
      </div>
      <label className="relative mb-4 block">
        <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-white/35" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="جستجو..."
          className="h-10 w-full rounded-lg border border-[#1f1f1f] bg-[#0a0a0a] px-10 text-right text-xs text-white outline-none placeholder:text-white/25 transition-all duration-300 ease-out hover:border-[#2a2a2e] focus:border-[#f06b16] focus:shadow-[0_0_0_3px_rgba(240,107,22,0.12)]"
        />
      </label>
      {loading ? (
        <div
          className="flex min-h-52 items-center justify-center"
          role="status"
          aria-label="در حال دریافت کاربران"
        >
          <div className="size-6 animate-spin rounded-full border-2 border-white/15 border-t-[#f06b16]" />
        </div>
      ) : (
        <div className="space-y-2">
          {displayUsers.map((user) => (
            <article
              key={user.id}
              className="relative rounded-xl border border-[#1f1f1f] bg-[#18181b] p-3.5"
            >
              <div className="flex items-center gap-3.5">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-full border border-[#1f1f1f] bg-[#0a0a0a] text-white/35">
                  <UserRound className="size-[18px]" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="truncate text-[13px] font-semibold text-white">
                      {user.name}
                    </h3>
                    <span
                      className={`rounded px-1.5 py-0.5 text-[10px] ${user.deletedAt ? "bg-red-500/15 text-red-400" : user.status === "active" ? "bg-green-500/15 text-green-400" : "bg-amber-500/15 text-amber-400"}`}
                    >
                      {user.deletedAt
                        ? "حذف‌شده"
                        : user.status === "active"
                          ? "فعال"
                          : "غیرفعال"}
                    </span>
                  </div>
                  <p dir="ltr" className="truncate text-[11px] text-white/40">
                    {user.email}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[10px] text-white/25">
                    <span>
                      عضو از{" "}
                      {new Date(user.createdAt).toLocaleDateString("fa-IR")}
                    </span>
                    <span className="rounded-full bg-[#27272a] px-1.5 py-0.5">
                      بدون اشتراک
                    </span>
                  </div>
                </div>
                <div data-user-menu className="relative shrink-0">
                  <AdminRippleButton
                    onClick={() => toggleUserMenu(user.id)}
                    className="rounded-lg p-1.5 text-white/45 hover:bg-white/5"
                  >
                    <MoreVertical className="size-5" strokeWidth={1.9} />
                  </AdminRippleButton>
                  {menu === user.id && (
                    <div
                      className={`absolute left-0 top-9 z-20 w-[158px] origin-top-left space-y-1 rounded-[24px] border border-white/10 bg-[#050505] p-2 shadow-[0_18px_38px_rgba(0,0,0,0.42)] ${closingMenu === user.id ? "animate-[admin-menu-out_160ms_ease-in]" : "animate-[admin-menu-in_170ms_ease-out]"}`}
                    >
                      {user.deletedAt ? (
                        <>
                          <AdminRippleButton
                            onClick={() => updateUser(user.id, "active")}
                            className="flex h-9 w-full items-center gap-2.5 rounded-[15px] px-2.5 text-[10.5px] font-bold text-green-300 hover:bg-white/5"
                          >
                            <CheckCircle2
                              className="size-[18px]"
                              strokeWidth={1.9}
                            />
                            بازیابی
                          </AdminRippleButton>
                          <AdminRippleButton
                            onClick={() =>
                              updateUser(user.id, "permanent-delete")
                            }
                            className="flex h-9 w-full items-center gap-2.5 rounded-[15px] px-2.5 text-[10.5px] font-bold text-red-300 hover:bg-white/5"
                          >
                            <Trash2 className="size-[18px]" strokeWidth={1.9} />
                            حذف دائمی
                          </AdminRippleButton>
                        </>
                      ) : (
                        <>
                          {user.status === "active" ? (
                            <AdminRippleButton
                              onClick={() => updateUser(user.id, "inactive")}
                              className="flex h-9 w-full items-center gap-2.5 rounded-[15px] px-2.5 text-[10.5px] font-bold text-white hover:bg-white/5"
                            >
                              <Ban className="size-[18px]" strokeWidth={1.9} />
                              غیرفعال کردن
                            </AdminRippleButton>
                          ) : (
                            <AdminRippleButton
                              onClick={() => updateUser(user.id, "active")}
                              className="flex h-9 w-full items-center gap-2.5 rounded-[15px] px-2.5 text-[10.5px] font-bold text-green-300 hover:bg-white/5"
                            >
                              <CheckCircle2
                                className="size-[18px]"
                                strokeWidth={1.9}
                              />
                              فعال کردن
                            </AdminRippleButton>
                          )}
                          <AdminRippleButton
                            onClick={() => updateUser(user.id, "reset")}
                            className="flex h-9 w-full items-center gap-2.5 rounded-[15px] px-2.5 text-[10.5px] font-bold text-white hover:bg-white/5"
                          >
                            <RotateCcw
                              className="size-[18px]"
                              strokeWidth={1.9}
                            />
                            ریست
                          </AdminRippleButton>
                          <AdminRippleButton
                            onClick={() => updateUser(user.id, "delete")}
                            className="flex h-9 w-full items-center gap-2.5 rounded-[15px] px-2.5 text-[10.5px] font-bold text-[#ffaaaa] hover:bg-white/5"
                          >
                            <Trash2 className="size-[18px]" strokeWidth={1.9} />
                            حذف
                          </AdminRippleButton>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
      {displayUsers.length === 0 && !loading && (
        <div className="py-12 text-center text-sm text-white/35">
          نتیجه‌ای یافت نشد
        </div>
      )}
      {!loading && totalPages > 1 && (
        <div className="mt-5 flex items-center justify-center gap-2 text-xs text-white/40">
          <AdminRippleButton
            onClick={() => fetchPage(page - 1)}
            className="rounded-lg bg-[#18181b] px-3 py-2 disabled:opacity-30"
            disabled={page === 1}
          >
            قبلی
          </AdminRippleButton>
          <span className="min-w-[104px] text-center">
            {rangeStart} تا {rangeEnd} از {totalUsers}
          </span>
          <AdminRippleButton
            onClick={() => fetchPage(page + 1)}
            className="rounded-lg bg-[#18181b] px-3 py-2 disabled:opacity-30"
            disabled={page >= totalPages}
          >
            بعدی
          </AdminRippleButton>
        </div>
      )}
    </section>
  );
}
