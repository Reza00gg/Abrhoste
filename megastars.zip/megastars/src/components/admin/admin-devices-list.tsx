"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AlertCircle, Ban, CheckCircle2, Info, LogOut, MonitorSmartphone, X } from "lucide-react";
import { AdminRippleButton } from "@/components/admin/admin-ripple-button";

type Toast = { message: string; tone: "success" | "error" };

type AdminDevice = {
  id: string;
  adminName: string;
  adminEmail: string;
  ipAddress: string | null;
  userAgent: string | null;
  browser: string;
  os: string;
  device: string;
  createdAt: string;
  lastUsedAt: string;
  expiresAt: string;
  isCurrent: boolean;
};

const devicesStore: { items: AdminDevice[] | null } = { items: null };

function rememberDevices(items: AdminDevice[]) {
  devicesStore.items = items;
}

function clearDevicesMemory() {
  devicesStore.items = null;
}

function formatDate(value: string) {
  return new Date(value).toLocaleString("fa-IR", {
    timeZone: "Asia/Tehran",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function Detail({ label, value, ltr = false }: { label: string; value: string; ltr?: boolean }) {
  return <div className="rounded-xl bg-white/[0.035] p-3"><p className="text-[11px] text-white/35">{label}</p><p dir={ltr ? "ltr" : "rtl"} className="mt-1.5 break-words text-xs leading-5 text-white/75">{value}</p></div>;
}

export function AdminDevicesList() {
  const router = useRouter();
  const [items, setItems] = useState<AdminDevice[]>(() => devicesStore.items ?? []);
  const [selected, setSelected] = useState<AdminDevice | null>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const [toastClosing, setToastClosing] = useState(false);
  const [loading, setLoading] = useState(() => devicesStore.items === null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const toastTimer = useRef<number | null>(null);
  const toastCloseTimer = useRef<number | null>(null);

  function closeToast() {
    if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
    setToastClosing(true);
    toastCloseTimer.current = window.setTimeout(() => {
      setToast(null);
      setToastClosing(false);
    }, 220);
  }

  function showToast(message: string, tone: Toast["tone"] = "success") {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
    setToastClosing(false);
    setToast({ message, tone });
    toastTimer.current = window.setTimeout(() => closeToast(), 2600);
  }

  async function fetchDevices(showLoading = true, force = false) {
    if (devicesStore.items && !force) {
      setItems(devicesStore.items);
      setLoading(false);
      return;
    }

    if (showLoading) setLoading(true);
    try {
      const response = await fetch("/api/admin/security/devices", { cache: "no-store" });
      if (!response.ok) {
        router.replace("/adminChash7nakg");
        router.refresh();
        return;
      }
      const data = await response.json();
      const nextItems = data.items ?? [];
      rememberDevices(nextItems);
      setItems(nextItems);
    } finally {
      if (showLoading) setLoading(false);
    }
  }

  useEffect(() => {
    const timer = devicesStore.items ? null : window.setTimeout(() => {
      fetchDevices();
    }, 0);
    return () => {
      if (timer) window.clearTimeout(timer);
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
      if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function deviceAction(id: string, action: "kick" | "block") {
    setBusyId(id);
    setToast(null);
    setToastClosing(false);
    const response = await fetch(`/api/admin/security/devices/${id}${action === "block" ? "/block" : ""}`, {
      method: action === "block" ? "POST" : "DELETE",
    });
    const result = await response.json().catch(() => null);
    setBusyId(null);

    if (!response.ok) {
      showToast(result?.message ?? "عملیات انجام نشد.", "error");
      return;
    }

    setSelected(null);
    clearDevicesMemory();
    showToast(action === "block" ? "دستگاه مسدود و از پنل خارج شد." : "دستگاه از پنل خارج شد.");
    if (result?.kickedCurrent || result?.blockedCurrent) {
      router.replace("/adminChash7nakg");
      router.refresh();
      return;
    }
    await fetchDevices(false, true);
  }

  return (
    <section>
      {toast && <div className={`fixed bottom-5 left-1/2 z-50 flex min-w-[250px] max-w-[calc(100vw-32px)] -translate-x-1/2 items-center gap-2.5 rounded-2xl border px-4 py-3.5 text-[13px] font-medium shadow-2xl ${toastClosing ? "animate-[toast-out_220ms_ease-in]" : "animate-[toast-in_220ms_ease-out]"} ${toast.tone === "success" ? "border-emerald-400/15 bg-[#151518] text-white" : "border-red-400/20 bg-[#1b1010] text-red-100"}`}>{toast.tone === "success" ? <CheckCircle2 className="size-[18px] shrink-0 text-emerald-400" /> : <AlertCircle className="size-[18px] shrink-0 text-red-300" />}<span>{toast.message}</span></div>}

      {loading ? <div className="flex min-h-52 items-center justify-center"><div className="size-6 animate-spin rounded-full border-2 border-white/15 border-t-[#f06b16]" /></div> : items.length ? <div className="space-y-2">
        {items.map((item) => <article key={item.id} className="rounded-2xl border border-[#1f1f1f] bg-[#18181b] p-3.5">
          <div className="flex items-center gap-3">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-full border border-[#252529] bg-[#0a0a0a] text-white/45"><MonitorSmartphone className="size-[18px]" strokeWidth={1.9} /></span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2"><h3 className="truncate text-[13px] font-bold text-white">{item.device} • {item.browser}</h3>{item.isCurrent && <span className="rounded-full bg-emerald-400/10 px-2 py-0.5 text-[10px] text-emerald-300">فعلی</span>}</div>
              <p className="mt-1 truncate text-[11px] text-white/40">{item.os} • ورود {formatDate(item.createdAt)}</p>
              <p dir="ltr" className="mt-0.5 truncate text-[10px] text-white/25">{item.ipAddress ?? "IP نامشخص"}</p>
            </div>
            <div className="flex shrink-0 items-center gap-1">
              <AdminRippleButton onClick={() => setSelected(item)} className="rounded-lg p-2 text-white/45 hover:bg-white/5 hover:text-white"><Info className="size-4" strokeWidth={1.9} /></AdminRippleButton>
              <AdminRippleButton disabled={busyId === item.id} onClick={() => deviceAction(item.id, "kick")} className="rounded-lg p-2 text-orange-300/80 hover:bg-white/5"><LogOut className="size-4" strokeWidth={1.9} /></AdminRippleButton>
              <AdminRippleButton disabled={busyId === item.id} onClick={() => deviceAction(item.id, "block")} className="rounded-lg p-2 text-red-300/80 hover:bg-white/5"><Ban className="size-4" strokeWidth={1.9} /></AdminRippleButton>
            </div>
          </div>
        </article>)}
      </div> : <div className="rounded-2xl border border-[#1f1f1f] bg-[#151518] px-4 py-10 text-center text-sm text-white/35">دستگاه فعالی پیدا نشد.</div>}

      {selected && <div className="fixed inset-0 z-[80]">
        <button aria-label="بستن جزئیات" onClick={() => setSelected(null)} className="absolute inset-0 bg-black/60" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-h-[84dvh] w-full max-w-[520px] animate-[admin-sheet-in_220ms_ease-out] overflow-y-auto rounded-t-[28px] border border-white/10 bg-[#111114] p-4 pb-6 shadow-[0_-18px_45px_rgba(0,0,0,0.35)]">
          <div className="mb-4 flex items-center justify-between">
            <div><p className="text-[11px] text-white/35">جزئیات دستگاه</p><h3 className="mt-1 text-base font-bold">{selected.device} • {selected.browser}</h3></div>
            <button onClick={() => setSelected(null)} className="rounded-xl p-2 text-white/45 hover:bg-white/5"><X className="size-5" strokeWidth={1.9} /></button>
          </div>
          <div className="grid gap-2">
            <Detail label="مدیر" value={`${selected.adminName} - ${selected.adminEmail}`} />
            <Detail label="سیستم و مرورگر" value={`${selected.os} / ${selected.browser}`} />
            <Detail label="زمان ورود" value={formatDate(selected.createdAt)} />
            <Detail label="آخرین فعالیت" value={formatDate(selected.lastUsedAt)} />
            <Detail label="اعتبار نشست تا" value={formatDate(selected.expiresAt)} />
            <Detail label="IP" value={selected.ipAddress ?? "نامشخص"} ltr />
            <Detail label="User Agent" value={selected.userAgent ?? "نامشخص"} ltr />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <AdminRippleButton disabled={busyId === selected.id} onClick={() => deviceAction(selected.id, "kick")} className="flex h-11 items-center justify-center gap-2 rounded-xl bg-white/[0.08] text-xs font-bold text-orange-200 disabled:opacity-50"><LogOut className="size-4" />خروج دستگاه</AdminRippleButton>
            <AdminRippleButton disabled={busyId === selected.id} onClick={() => deviceAction(selected.id, "block")} className="flex h-11 items-center justify-center gap-2 rounded-xl bg-red-500/15 text-xs font-bold text-red-200 disabled:opacity-50"><Ban className="size-4" />مسدودسازی</AdminRippleButton>
          </div>
        </div>
      </div>}
    </section>
  );
}
