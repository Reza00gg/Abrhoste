"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { ShieldCheck } from "lucide-react";

export function AdminLogin() {
  const router = useRouter();
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const identity = String(data.get("email") ?? "").trim();
    const password = String(data.get("password") ?? "");
    const deniedMessage = "دسترسی غیرمجاز است.";

    setMessage(null);
    if (!identity && !password) {
      setMessage("ایمیل ادمین و رمز عبور را وارد کنید.");
      return;
    }
    if (!identity) {
      setMessage("ایمیل ادمین را وارد کنید.");
      return;
    }
    if (!password) {
      setMessage("رمز عبور را وارد کنید.");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identity, password }),
      });
      const result = await response.json().catch(() => ({ message: deniedMessage }));
      if (!response.ok) setMessage(result.message ?? deniedMessage);
      else router.replace("/adminChash7nakg");
    } catch {
      setMessage(deniedMessage);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main dir="rtl" className="flex min-h-dvh items-center justify-center bg-[#09090b] px-5 text-white">
      <div className="w-full max-w-[350px]">
        <div className="mb-7 text-center">
          <span className="mx-auto mb-3 flex size-10 items-center justify-center rounded-2xl bg-[#f06b16]/10 text-[#f06b16]"><ShieldCheck className="size-5" strokeWidth={1.9} /></span>
          <h1 className="text-xl font-bold">ورود مدیریت</h1>
          <p className="mt-2 text-xs leading-5 text-white/45">ورود امن به پنل مدیریت</p>
        </div>
        <form onSubmit={submit} noValidate className="space-y-4">
          <label className="block">
            <span className="mb-1.5 block text-right text-[11px] font-medium text-white/45">ایمیل ادمین</span>
            <input name="email" type="email" inputMode="email" autoComplete="username" placeholder="ایمیل ادمین" dir="rtl" className="h-11 w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 text-right text-sm text-white outline-none transition-all duration-300 placeholder:text-white/25 focus:border-[#f06b16] focus:bg-white/[0.05] focus:shadow-[0_0_0_3px_rgba(240,107,22,0.12)]" />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-right text-[11px] font-medium text-white/45">رمز عبور</span>
            <input name="password" type="password" autoComplete="current-password" placeholder="رمز عبور" dir="rtl" className="h-11 w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 text-right text-sm text-white outline-none transition-all duration-300 placeholder:text-white/25 focus:border-[#f06b16] focus:bg-white/[0.05] focus:shadow-[0_0_0_3px_rgba(240,107,22,0.12)]" />
          </label>
          {message && <p className="rounded-xl border border-red-400/15 bg-red-500/10 px-3 py-2.5 text-center text-xs text-red-200">{message}</p>}
          <button type="submit" disabled={loading} className="h-11 w-full rounded-xl bg-[#f06b16] text-sm font-bold text-white transition-[opacity,transform] active:scale-[0.99] disabled:opacity-50">{loading ? "در حال بررسی..." : "ورود به پنل مدیریت"}</button>
        </form>
      </div>
    </main>
  );
}
