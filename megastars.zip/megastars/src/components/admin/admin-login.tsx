"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { LockKeyhole, ShieldCheck } from "lucide-react";

export function AdminLogin() {
  const router = useRouter();
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setMessage(null);
    const data = new FormData(event.currentTarget);
    const response = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identity: data.get("email"), password: data.get("password") }),
    });
    const result = await response.json();
    if (!response.ok) setMessage(result.message);
    else router.replace("/adminChash7nakg");
    setLoading(false);
  }

  return (
    <main dir="rtl" className="flex min-h-dvh items-center justify-center bg-[#09090b] px-5 text-white">
      <div className="w-full max-w-[360px]">
        <div className="mb-8 text-center">
          <span className="mx-auto mb-3 flex size-10 items-center justify-center text-[#f06b16]"><ShieldCheck className="size-5" /></span>
          <h1 className="text-xl font-bold">ورود مدیریت</h1>
          <p className="mt-2 text-xs text-white/45">ورود امن به مدیریت MegaStars</p>
        </div>
        <form onSubmit={submit} className="mt-7 space-y-3">
          <input name="email" type="email" required placeholder="ایمیل ادمین" dir="ltr" className="h-11 w-full border-b border-white/15 bg-transparent px-4 text-left text-sm outline-none focus:border-[#f06b16]" />
          <div className="relative">
            <LockKeyhole className="absolute right-4 top-1/2 size-4 -translate-y-1/2 text-white/40" />
            <input name="password" type="password" required placeholder="رمز عبور" className="h-11 w-full border-b border-white/15 bg-transparent px-11 text-right text-sm outline-none focus:border-[#f06b16]" />
          </div>
          {message && <p className="rounded-xl bg-red-500/10 px-3 py-2 text-center text-xs text-red-300">{message}</p>}
          <button disabled={loading} className="h-11 w-full rounded-xl bg-[#f06b16] text-sm font-bold text-white transition-opacity disabled:opacity-50">{loading ? "در حال بررسی..." : "ورود به پنل"}</button>
        </form>
      </div>
    </main>
  );
}
