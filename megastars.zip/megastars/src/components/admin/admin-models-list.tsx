"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  CheckCircle2,
  Eye,
  EyeOff,
  MoreVertical,
  Pencil,
  Plus,
  Power,
  SlidersHorizontal,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { AdminRippleButton } from "@/components/admin/admin-ripple-button";

type AiModel = {
  id: string;
  name: string;
  apiModel: string;
  status: "active" | "inactive" | "hidden";
  builtIn: boolean;
  icon: string | null;
  apiKeyMasked: string;
  lastTestAt: string | null;
  lastTestMessage: string | null;
  createdAt: string | null;
  updatedAt: string | null;
};

type Toast = { message: string; tone: "success" | "error" };
type SheetMode = "add" | "edit" | "details";

type FormState = {
  id?: string;
  name: string;
  apiModel: string;
  apiKey: string;
  icon: string;
  status: "active" | "inactive" | "hidden";
};

const emptyForm: FormState = {
  name: "",
  apiModel: "",
  apiKey: "",
  icon: "",
  status: "active",
};

function statusLabel(status: AiModel["status"] | FormState["status"]) {
  return status === "active"
    ? "فعال"
    : status === "inactive"
      ? "غیرفعال"
      : "مخفی";
}

function formatDate(value: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleString("fa-IR", {
    timeZone: "Asia/Tehran",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

function GeminiModelIcon() {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      fill="none"
      className="size-4 shrink-0"
    >
      <path
        d="M12 2.35c.75 4.85 3.55 7.65 8.4 8.4-4.85.75-7.65 3.55-8.4 8.4-.75-4.85-3.55-7.65-8.4-8.4 4.85-.75 7.65-3.55 8.4-8.4Z"
        fill="url(#admin-gemini-icon-gradient)"
      />
      <defs>
        <linearGradient
          id="admin-gemini-icon-gradient"
          x1="3.6"
          y1="3.2"
          x2="19.7"
          y2="18.9"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#4285f4" />
          <stop offset="0.42" stopColor="#a142f4" />
          <stop offset="0.72" stopColor="#ea4335" />
          <stop offset="1" stopColor="#fbbc04" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function ModelAvatar({
  model,
  className = "size-10",
}: {
  model: Pick<AiModel, "icon" | "name">;
  className?: string;
}) {
  if (model.icon && model.icon !== "gemini") {
    return (
      <span
        className={`flex ${className} shrink-0 overflow-hidden rounded-full border border-[#252529] bg-[#0a0a0a]`}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={model.icon}
          alt={model.name}
          className="size-full object-cover"
        />
      </span>
    );
  }

  return (
    <span
      className={`flex ${className} shrink-0 items-center justify-center rounded-full border border-[#252529] bg-[#0a0a0a] text-white/45`}
    >
      {model.icon === "gemini" ? (
        <GeminiModelIcon />
      ) : (
        <SlidersHorizontal className="size-[18px]" strokeWidth={1.9} />
      )}
    </span>
  );
}

function Detail({
  label,
  value,
  ltr = false,
}: {
  label: string;
  value: string;
  ltr?: boolean;
}) {
  return (
    <div className="rounded-xl bg-white/[0.035] p-3">
      <p className="text-[11px] text-white/35">{label}</p>
      <p
        dir={ltr ? "ltr" : "rtl"}
        className="mt-1.5 break-words text-xs leading-5 text-white/75"
      >
        {value}
      </p>
    </div>
  );
}

export function AdminModelsList() {
  const [items, setItems] = useState<AiModel[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [actionMenu, setActionMenu] = useState<string | null>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const [toastClosing, setToastClosing] = useState(false);
  const [sheetMode, setSheetMode] = useState<SheetMode | null>(null);
  const [sheetClosing, setSheetClosing] = useState(false);
  const [selected, setSelected] = useState<AiModel | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [testing, setTesting] = useState(false);
  const [testOk, setTestOk] = useState(false);
  const [saving, setSaving] = useState(false);
  const toastTimer = useRef<number | null>(null);
  const toastCloseTimer = useRef<number | null>(null);
  const sheetTimer = useRef<number | null>(null);

  function closeToast() {
    if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
    setToastClosing(true);
    toastCloseTimer.current = window.setTimeout(() => {
      setToast(null);
      setToastClosing(false);
    }, 220);
  }

  function showToast(message: string, tone: Toast["tone"] = "success") {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
    setToastClosing(false);
    setToast({ message, tone });
    toastTimer.current = window.setTimeout(() => closeToast(), 2600);
  }

  async function fetchModels(showLoading = true) {
    if (showLoading) setLoading(true);
    const response = await fetch("/api/admin/models", { cache: "no-store" });
    if (response.ok) {
      const data = await response.json();
      setItems(data.items ?? []);
    } else {
      showToast("دریافت لیست مدل‌ها انجام نشد.", "error");
    }
    if (showLoading) setLoading(false);
  }

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void fetchModels();
    }, 0);
    return () => {
      window.clearTimeout(timer);
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
      if (toastCloseTimer.current) window.clearTimeout(toastCloseTimer.current);
      if (sheetTimer.current) window.clearTimeout(sheetTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!actionMenu) return;
    function closeFromOutside(event: MouseEvent) {
      if (!(event.target as HTMLElement).closest("[data-model-menu]"))
        setActionMenu(null);
    }
    document.addEventListener("mousedown", closeFromOutside);
    return () => document.removeEventListener("mousedown", closeFromOutside);
  }, [actionMenu]);

  function openAdd() {
    setForm(emptyForm);
    setSelected(null);
    setTestOk(false);
    setSheetClosing(false);
    setSheetMode("add");
  }

  function openEdit(item: AiModel) {
    setSelected(item);
    setForm({
      id: item.id,
      name: item.name,
      apiModel: item.apiModel,
      apiKey: "",
      icon: item.icon ?? "",
      status: item.status,
    });
    setTestOk(false);
    setSheetClosing(false);
    setSheetMode("edit");
  }

  function openDetails(item: AiModel) {
    setSelected(item);
    setSheetClosing(false);
    setSheetMode("details");
  }

  function closeSheet() {
    if (sheetClosing) return;
    setSheetClosing(true);
    sheetTimer.current = window.setTimeout(() => {
      setSheetMode(null);
      setSelected(null);
      setForm(emptyForm);
      setTestOk(false);
      setSheetClosing(false);
    }, 200);
  }

  async function readIconFile(file: File) {
    if (!file.type.startsWith("image/")) {
      showToast("فقط فایل تصویر برای آیکن قابل قبول است.", "error");
      return;
    }
    if (file.size > 300_000) {
      showToast("حجم آیکن بهتر است کمتر از ۳۰۰KB باشد.", "error");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setForm((current) => ({ ...current, icon: String(reader.result ?? "") }));
    };
    reader.readAsDataURL(file);
  }

  async function testConnection() {
    setTesting(true);
    setTestOk(false);
    const response = await fetch("/api/admin/models/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: form.id,
        apiModel: form.apiModel,
        apiKey: form.apiKey,
      }),
    });
    const result = await response.json().catch(() => null);
    setTesting(false);
    if (!response.ok) {
      showToast(result?.message ?? "تست اتصال ناموفق بود.", "error");
      return;
    }
    setTestOk(true);
    showToast(`${result.message} (${result.latencyMs}ms)`);
  }

  async function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!testOk || saving) return;
    setSaving(true);
    const endpoint =
      sheetMode === "edit" && form.id
        ? `/api/admin/models/${form.id}`
        : "/api/admin/models";
    const response = await fetch(endpoint, {
      method: sheetMode === "edit" ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const result = await response.json().catch(() => null);
    setSaving(false);
    if (!response.ok) {
      showToast(result?.message ?? "ذخیره مدل انجام نشد.", "error");
      return;
    }
    await fetchModels(false);
    showToast(sheetMode === "edit" ? "مدل ویرایش شد." : "مدل اضافه شد.");
    closeSheet();
  }

  async function updateStatus(item: AiModel, status: AiModel["status"]) {
    if (item.builtIn) return;
    setBusyId(item.id);
    const response = await fetch(`/api/admin/models/${item.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: item.name,
        apiModel: item.apiModel,
        icon: item.icon ?? "",
        status,
      }),
    });
    setBusyId(null);
    setActionMenu(null);
    if (!response.ok) {
      const result = await response.json().catch(() => null);
      showToast(result?.message ?? "تغییر وضعیت انجام نشد.", "error");
      return;
    }
    await fetchModels(false);
    showToast("وضعیت مدل تغییر کرد.");
  }

  async function deleteModel(item: AiModel) {
    if (item.builtIn) return;
    setBusyId(item.id);
    const response = await fetch(`/api/admin/models/${item.id}`, {
      method: "DELETE",
    });
    setBusyId(null);
    setActionMenu(null);
    if (!response.ok) {
      const result = await response.json().catch(() => null);
      showToast(result?.message ?? "حذف مدل انجام نشد.", "error");
      return;
    }
    setItems((current) => current.filter((model) => model.id !== item.id));
    showToast("مدل حذف شد.");
  }

  return (
    <section>
      {toast && (
        <div
          className={`fixed bottom-5 left-1/2 z-[100] flex min-w-[250px] max-w-[calc(100vw-32px)] -translate-x-1/2 items-center gap-2.5 rounded-2xl border px-4 py-3.5 text-[13px] font-medium shadow-2xl ${toastClosing ? "animate-[toast-out_220ms_ease-in]" : "animate-[toast-in_220ms_ease-out]"} ${toast.tone === "success" ? "border-emerald-400/15 bg-[#151518] text-white" : "border-red-400/20 bg-[#1b1010] text-red-100"}`}
        >
          {toast.tone === "success" ? (
            <CheckCircle2 className="size-[18px] shrink-0 text-emerald-400" />
          ) : (
            <AlertCircle className="size-[18px] shrink-0 text-red-300" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

      <div className="mb-4 flex justify-end">
        <AdminRippleButton
          onClick={openAdd}
          className="flex h-10 items-center gap-2 rounded-xl bg-[#f06b16] px-4 text-xs font-bold text-white"
        >
          <Plus className="size-4" strokeWidth={2} />
          افزودن مدل
        </AdminRippleButton>
      </div>

      {loading ? (
        <div className="flex min-h-52 items-center justify-center">
          <div className="size-6 animate-spin rounded-full border-2 border-white/15 border-t-[#f06b16]" />
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((item) => (
            <article
              key={item.id}
              className={`rounded-2xl border border-[#1f1f1f] bg-[#18181b] p-3.5 ${item.status === "hidden" ? "opacity-55" : item.status === "inactive" ? "opacity-70" : ""}`}
            >
              <div className="flex items-center gap-3">
                <ModelAvatar model={item} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="truncate text-[13px] font-bold text-white">
                      {item.name}
                    </h3>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] ${item.status === "active" ? "bg-emerald-400/10 text-emerald-300" : item.status === "inactive" ? "bg-amber-400/10 text-amber-300" : "bg-white/10 text-white/45"}`}
                    >
                      {statusLabel(item.status)}
                    </span>
                    {item.builtIn && (
                      <span className="rounded-full bg-blue-400/10 px-2 py-0.5 text-[10px] text-blue-300">
                        سیستمی
                      </span>
                    )}
                  </div>
                  <p
                    dir="ltr"
                    className="mt-1 truncate text-[11px] text-white/35"
                  >
                    {item.apiModel}
                  </p>
                </div>
                <div data-model-menu className="relative shrink-0">
                  <AdminRippleButton
                    onClick={() =>
                      setActionMenu(actionMenu === item.id ? null : item.id)
                    }
                    className="rounded-lg p-2 text-white/45 hover:bg-white/5 hover:text-white"
                  >
                    <MoreVertical className="size-5" strokeWidth={1.9} />
                  </AdminRippleButton>
                  {actionMenu === item.id && (
                    <div className="absolute left-0 top-10 z-30 w-36 animate-[admin-menu-in_160ms_ease-out] rounded-2xl border border-white/10 bg-[#09090b] p-2 shadow-xl">
                      <AdminRippleButton
                        onClick={() => {
                          setActionMenu(null);
                          openDetails(item);
                        }}
                        className="flex h-8 w-full items-center gap-2 rounded-xl px-2 text-[10.5px] font-bold text-white hover:bg-white/5"
                      >
                        <Eye className="size-4" />
                        جزئیات
                      </AdminRippleButton>
                      {!item.builtIn && (
                        <AdminRippleButton
                          onClick={() => {
                            setActionMenu(null);
                            openEdit(item);
                          }}
                          className="flex h-8 w-full items-center gap-2 rounded-xl px-2 text-[10.5px] font-bold text-blue-300 hover:bg-white/5"
                        >
                          <Pencil className="size-4" />
                          ویرایش
                        </AdminRippleButton>
                      )}
                      {!item.builtIn && (
                        <AdminRippleButton
                          disabled={busyId === item.id}
                          onClick={() =>
                            updateStatus(
                              item,
                              item.status === "active" ? "inactive" : "active",
                            )
                          }
                          className="flex h-8 w-full items-center gap-2 rounded-xl px-2 text-[10.5px] font-bold text-amber-300 hover:bg-white/5"
                        >
                          <Power className="size-4" />
                          {item.status === "active" ? "غیرفعال" : "فعال"}
                        </AdminRippleButton>
                      )}
                      {!item.builtIn && (
                        <AdminRippleButton
                          disabled={busyId === item.id}
                          onClick={() =>
                            updateStatus(
                              item,
                              item.status === "hidden" ? "active" : "hidden",
                            )
                          }
                          className="flex h-8 w-full items-center gap-2 rounded-xl px-2 text-[10.5px] font-bold text-white/75 hover:bg-white/5"
                        >
                          {item.status === "hidden" ? (
                            <Eye className="size-4" />
                          ) : (
                            <EyeOff className="size-4" />
                          )}
                          {item.status === "hidden" ? "نمایش" : "مخفی"}
                        </AdminRippleButton>
                      )}
                      {!item.builtIn && (
                        <AdminRippleButton
                          disabled={busyId === item.id}
                          onClick={() => deleteModel(item)}
                          className="flex h-8 w-full items-center gap-2 rounded-xl px-2 text-[10.5px] font-bold text-red-300 hover:bg-white/5"
                        >
                          <Trash2 className="size-4" />
                          حذف
                        </AdminRippleButton>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {sheetMode && (
        <div className="fixed inset-0 z-[80]">
          <button
            aria-label="بستن"
            onClick={closeSheet}
            className="absolute inset-0 bg-black/60"
          />
          <div
            className={`absolute inset-x-0 bottom-0 mx-auto max-h-[84dvh] w-full max-w-[520px] overflow-y-auto rounded-t-[28px] border border-white/10 bg-[#111114] p-4 pb-6 shadow-[0_-18px_45px_rgba(0,0,0,0.35)] ${sheetClosing ? "animate-[admin-sheet-out_200ms_ease-in]" : "animate-[admin-sheet-in_220ms_ease-out]"}`}
          >
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-[11px] text-white/35">
                  {sheetMode === "details"
                    ? "جزئیات مدل"
                    : sheetMode === "edit"
                      ? "ویرایش مدل"
                      : "افزودن مدل"}
                </p>
                <h3 className="mt-1 text-base font-bold">
                  {sheetMode === "details" ? selected?.name : "مدل هوش مصنوعی"}
                </h3>
              </div>
              <button
                onClick={closeSheet}
                className="rounded-xl p-2 text-white/45 hover:bg-white/5"
              >
                <X className="size-5" strokeWidth={1.9} />
              </button>
            </div>

            {sheetMode === "details" && selected ? (
              <div className="grid gap-2">
                <div className="mb-1 flex justify-center">
                  <ModelAvatar model={selected} className="size-14" />
                </div>
                <Detail label="نام مدل" value={selected.name} />
                <Detail label="API مدل" value={selected.apiModel} ltr />
                <Detail label="وضعیت" value={statusLabel(selected.status)} />
                <Detail label="API Key" value={selected.apiKeyMasked} ltr />
                <Detail
                  label="آخرین تست"
                  value={selected.lastTestMessage ?? "—"}
                />
                <Detail
                  label="زمان آخرین تست"
                  value={formatDate(selected.lastTestAt)}
                />
                <Detail
                  label="آخرین بروزرسانی"
                  value={formatDate(selected.updatedAt)}
                />
              </div>
            ) : (
              <form onSubmit={submitForm} className="space-y-3">
                <label className="block">
                  <span className="mb-1.5 block text-[11px] text-white/40">
                    اسم مدل
                  </span>
                  <input
                    value={form.name}
                    onChange={(event) => {
                      setForm((current) => ({
                        ...current,
                        name: event.target.value,
                      }));
                      setTestOk(false);
                    }}
                    className="h-11 w-full rounded-xl border border-white/10 bg-white/[0.03] px-3 text-right text-sm text-white outline-none focus:border-[#f06b16]"
                    placeholder="مثلاً Gemini 3.1 Flash Lite"
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-[11px] text-white/40">
                    API مدل
                  </span>
                  <input
                    dir="ltr"
                    value={form.apiModel}
                    onChange={(event) => {
                      setForm((current) => ({
                        ...current,
                        apiModel: event.target.value,
                      }));
                      setTestOk(false);
                    }}
                    className="h-11 w-full rounded-xl border border-white/10 bg-white/[0.03] px-3 text-left text-sm text-white outline-none focus:border-[#f06b16]"
                    placeholder="gemini-3.1-flash-lite"
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-[11px] text-white/40">
                    API Key
                  </span>
                  <input
                    dir="ltr"
                    value={form.apiKey}
                    onChange={(event) => {
                      setForm((current) => ({
                        ...current,
                        apiKey: event.target.value,
                      }));
                      setTestOk(false);
                    }}
                    className="h-11 w-full rounded-xl border border-white/10 bg-white/[0.03] px-3 text-left text-sm text-white outline-none focus:border-[#f06b16]"
                    placeholder={
                      sheetMode === "edit"
                        ? "برای حفظ کلید فعلی خالی بگذارید"
                        : "API Key"
                    }
                  />
                </label>
                <div className="rounded-2xl border border-white/10 bg-white/[0.025] p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-[11px] text-white/40">آیکن مدل</span>
                    {form.icon && (
                      <ModelAvatar
                        model={{ name: form.name || "icon", icon: form.icon }}
                        className="size-8"
                      />
                    )}
                  </div>
                  <input
                    value={form.icon}
                    onChange={(event) =>
                      setForm((current) => ({
                        ...current,
                        icon: event.target.value,
                      }))
                    }
                    className="h-10 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-left text-xs text-white outline-none focus:border-[#f06b16]"
                    dir="ltr"
                    placeholder="لینک آیکن یا Data URL"
                  />
                  <label className="mt-2 flex h-9 cursor-pointer items-center justify-center gap-2 rounded-xl bg-white/[0.06] text-[11px] font-bold text-white">
                    <Upload className="size-4" />
                    آپلود آیکن از گالری
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(event) => {
                        const file = event.target.files?.[0];
                        if (file) void readIconFile(file);
                        event.target.value = "";
                      }}
                    />
                  </label>
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px] text-white/55">
                  {(["active", "inactive", "hidden"] as const).map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() =>
                        setForm((current) => ({ ...current, status }))
                      }
                      className={`h-9 rounded-xl border transition-colors ${form.status === status ? "border-[#f06b16] bg-[#f06b16]/15 text-white" : "border-white/10 bg-white/[0.03]"}`}
                    >
                      {statusLabel(status)}
                    </button>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <AdminRippleButton
                    type="button"
                    disabled={testing}
                    onClick={testConnection}
                    className="flex h-11 items-center justify-center rounded-xl bg-white/[0.08] text-xs font-bold text-white disabled:opacity-45"
                  >
                    {testing ? "در حال تست..." : "تست اتصال"}
                  </AdminRippleButton>
                  <button
                    type="submit"
                    disabled={!testOk || saving}
                    className="h-11 rounded-xl bg-[#f06b16] text-xs font-bold text-white transition-opacity disabled:opacity-35"
                  >
                    {saving
                      ? "در حال ذخیره..."
                      : sheetMode === "edit"
                        ? "ذخیره"
                        : "افزودن"}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
