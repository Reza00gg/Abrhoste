"use client";

import {
  ArrowUp,
  Bot,
  Clapperboard,
  Check,
  Copy,
  ImagePlus,
  Mic,
  Music2,
  Paperclip,
  Share2,
  X,
  Sparkles,
  ThumbsDown,
  ThumbsUp,
  Wrench,
} from "lucide-react";
import { useSearchParams } from "next/navigation";
import ReactMarkdown, { type Components } from "react-markdown";
import { type ReactNode, useEffect, useRef, useState } from "react";
import remarkBreaks from "remark-breaks";
import remarkGfm from "remark-gfm";

type ChatAttachment = {
  mimeType: string;
  data: string;
  name?: string;
};

type SelectedImage = ChatAttachment & {
  localId: string;
  previewUrl: string;
};

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  attachments?: ChatAttachment[];
};

type MessageReaction = "like" | "dislike";

const IMAGE_ONLY_PROMPT = "این تصویر را تحلیل کن.";
const DEFAULT_MODEL_ID = "system-gemini-3-1-flash-lite";

function normalizeAttachments(value: unknown): ChatAttachment[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((item) => {
    if (!item || typeof item !== "object") return [];
    const image = item as Record<string, unknown>;
    const mimeType = String(image.mimeType ?? "");
    const data = String(image.data ?? "");
    const name = String(image.name ?? "") || undefined;
    if (!mimeType.startsWith("image/") || !data) return [];
    return [{ mimeType, data, name }];
  });
}

function imageSrc(image: ChatAttachment) {
  return `data:${image.mimeType};base64,${image.data}`;
}

function normalizeMessage(item: {
  id: string;
  role: string;
  content: string;
  attachments?: unknown;
}): ChatMessage {
  return {
    id: item.id,
    role: item.role === "assistant" ? "assistant" : "user",
    content: item.content,
    attachments: normalizeAttachments(item.attachments),
  };
}

function countUnpairedAsterisks(line: string) {
  let count = 0;
  for (let index = 0; index < line.length; index += 1) {
    if (line[index] !== "*") continue;
    const previous = line[index - 1];
    const next = line[index + 1];
    if (previous !== "*" && next !== "*") count += 1;
  }
  return count;
}

function repairMarkdownLine(line: string) {
  let fixed = line
    .replace(/[ ]/g, " ")
    .replace(/[‌‍‎‏]/g, "")
    .replace(/^(\s*)#{1,6}\s*([0-9۰-۹٠-٩]+[.)]\s*)/, "$1$2")
    .replace(/^(\s*)([0-9۰-۹٠-٩]+[.)]\s*)#{1,6}\s*/, "$1$2")
    .replace(/^(\s*)(#{1,6})\s*(?=\S)/, "$1$2 ")
    .replace(/^(\s*)([-*+])(?=\S)/, "$1$2 ")
    .replace(/^(\s*)(\d+[.)])(?=\S)/, "$1$2 ");

  if (/^#{1,6}\s*$/.test(fixed.trim())) return "";
  if (/^[-*+]\s*$/.test(fixed.trim())) return "";

  const isListLine = /^\s*[-*+]\s+/.test(fixed);
  if (!isListLine && !fixed.trimEnd().endsWith("**")) {
    fixed = fixed.replace(/[\s‌‍]*\*[\s‌‍]*$/, "");
  }
  if (!isListLine && countUnpairedAsterisks(fixed) % 2 === 1) {
    fixed = fixed.replace(/[\s‌‍]*\*[\s‌‍]*$/, "");
  }

  return fixed;
}

function normalizeMarkdown(content: string) {
  return content
    .replace(/\r\n/g, "\n")
    .split("\n")
    .map(repairMarkdownLine)
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function extractNodeText(node: ReactNode): string {
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(extractNodeText).join("");
  if (node && typeof node === "object" && "props" in node) {
    return extractNodeText(
      (node as { props?: { children?: ReactNode } }).props?.children,
    );
  }
  return "";
}

function CodeBlock({
  children,
  softBg,
}: {
  children: ReactNode;
  softBg: string;
}) {
  const [copied, setCopied] = useState(false);
  async function copyCode() {
    const text = extractNodeText(children);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      setCopied(false);
    }
  }

  return (
    <pre
      className={`relative my-2 block w-full max-w-full overflow-x-auto overscroll-x-contain rounded-2xl ${softBg} p-3 pt-9 text-left text-xs leading-6 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden [&_code]:block [&_code]:min-w-max [&_code]:whitespace-pre [&_code]:rounded-none [&_code]:bg-transparent [&_code]:p-0 [&_code]:font-mono`}
      dir="ltr"
    >
      <button
        type="button"
        aria-label={copied ? "کپی شد" : "کپی کد"}
        onClick={() => void copyCode()}
        className={`absolute right-2 top-2 flex size-7 items-center justify-center rounded-lg border border-black/5 bg-white/75 shadow-sm backdrop-blur transition-colors active:scale-95 ${copied ? "text-[#13a538]" : "text-[#687493] hover:text-[#101a35]"}`}
      >
        {copied ? (
          <Check className="size-3.5" strokeWidth={2.1} />
        ) : (
          <Copy className="size-3.5" strokeWidth={1.9} />
        )}
      </button>
      {children}
    </pre>
  );
}

function createMarkdownComponents(inverse: boolean): Components {
  const textColor = inverse ? "text-white" : "text-[#202636]";
  const mutedText = inverse ? "text-white/75" : "text-[#697187]";
  const borderColor = inverse ? "border-white/20" : "border-[#e7eaf1]";
  const softBg = inverse ? "bg-white/[0.12]" : "bg-[#f4f6fb]";

  return {
    p: ({ children }) => <p className="my-1 leading-7">{children}</p>,
    h1: ({ children }) => (
      <h1
        className={`mb-2 mt-3 text-base font-extrabold leading-7 ${textColor}`}
      >
        {children}
      </h1>
    ),
    h2: ({ children }) => (
      <h2
        className={`mb-2 mt-3 text-[15px] font-extrabold leading-7 ${textColor}`}
      >
        {children}
      </h2>
    ),
    h3: ({ children }) => (
      <h3 className={`mb-1.5 mt-2.5 text-sm font-bold leading-7 ${textColor}`}>
        {children}
      </h3>
    ),
    h4: ({ children }) => (
      <h4 className={`mb-1 mt-2 text-sm font-bold leading-7 ${textColor}`}>
        {children}
      </h4>
    ),
    strong: ({ children }) => (
      <strong className="font-extrabold">{children}</strong>
    ),
    em: ({ children }) => <em className="italic">{children}</em>,
    ul: ({ children }) => (
      <ul className="my-2 list-disc space-y-1 pr-5 leading-7">{children}</ul>
    ),
    ol: ({ children }) => (
      <ol className="my-2 list-decimal space-y-1 pr-5 leading-7">{children}</ol>
    ),
    li: ({ children }) => <li className="pr-1 leading-7">{children}</li>,
    blockquote: ({ children }) => (
      <blockquote
        className={`my-2 border-r-2 ${borderColor} pr-3 ${mutedText}`}
      >
        {children}
      </blockquote>
    ),
    hr: () => <hr className={`my-3 border-t ${borderColor}`} />,
    a: ({ children, href }) => (
      <a
        href={href}
        target="_blank"
        rel="noreferrer"
        className="break-all font-bold text-[#2f6af4] underline underline-offset-4"
      >
        {children}
      </a>
    ),
    code: ({ children, className }) => {
      const isBlock = className?.includes("language-");
      return (
        <code
          className={
            isBlock
              ? `${className ?? ""} block min-w-max whitespace-pre bg-transparent p-0 font-mono text-[11px] leading-6`
              : `${className ?? ""} max-w-full break-all rounded-md ${softBg} px-1.5 py-0.5 text-[0.92em]`
          }
          dir="ltr"
        >
          {children}
        </code>
      );
    },
    pre: ({ children }) => <CodeBlock softBg={softBg}>{children}</CodeBlock>,
    table: ({ children }) => (
      <div className="my-2 max-w-full overflow-x-auto">
        <table
          className={`w-full min-w-[280px] border-collapse overflow-hidden rounded-xl text-xs ${textColor}`}
        >
          {children}
        </table>
      </div>
    ),
    thead: ({ children }) => <thead className={softBg}>{children}</thead>,
    th: ({ children }) => (
      <th className={`border ${borderColor} px-2 py-2 text-right font-bold`}>
        {children}
      </th>
    ),
    td: ({ children }) => (
      <td className={`border ${borderColor} px-2 py-2 align-top`}>
        {children}
      </td>
    ),
  };
}

function MarkdownText({
  content,
  inverse = false,
}: {
  content: string;
  inverse?: boolean;
}) {
  return (
    <div
      dir="auto"
      className={`break-words [unicode-bidi:plaintext] ${inverse ? "text-white" : "text-[#202636]"}`}
    >
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkBreaks]}
        components={createMarkdownComponents(inverse)}
      >
        {normalizeMarkdown(content)}
      </ReactMarkdown>
    </div>
  );
}

function createRevealChunks(text: string) {
  const chunks: string[] = [];
  const codeBlockPattern = /```[\s\S]*?```/g;
  let lastIndex = 0;

  function pushTextChunks(value: string) {
    const textChunks = value.match(/[^.!؟?。\n]+[.!؟?。]?\s*|\n+/g) ?? [];
    chunks.push(...textChunks);
  }

  for (const match of text.matchAll(codeBlockPattern)) {
    const index = match.index ?? 0;
    if (index > lastIndex) pushTextChunks(text.slice(lastIndex, index));
    const lines = match[0].split("\n");
    lines.forEach((line, lineIndex) => {
      chunks.push(`${line}${lineIndex < lines.length - 1 ? "\n" : ""}`);
    });
    lastIndex = index + match[0].length;
  }

  if (lastIndex < text.length) pushTextChunks(text.slice(lastIndex));
  return chunks.length ? chunks : [text];
}

function resizeImage(file: File): Promise<SelectedImage> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("file_read_failed"));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("image_load_failed"));
      image.onload = () => {
        const maxSide = 1280;
        const scale = Math.min(
          1,
          maxSide / Math.max(image.width, image.height),
        );
        const width = Math.max(1, Math.round(image.width * scale));
        const height = Math.max(1, Math.round(image.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext("2d");
        if (!context) {
          reject(new Error("canvas_failed"));
          return;
        }
        context.drawImage(image, 0, 0, width, height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
        const data = dataUrl.split(",")[1] ?? "";
        resolve({
          localId: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
          mimeType: "image/jpeg",
          data,
          name: file.name,
          previewUrl: dataUrl,
        });
      };
      image.src = String(reader.result ?? "");
    };
    reader.readAsDataURL(file);
  });
}
export default function Home() {
  const searchParams = useSearchParams();
  const requestedChatId = searchParams.get("m");
  const [deepThinking, setDeepThinking] = useState(false);
  const [message, setMessage] = useState("");
  const [selectedImages, setSelectedImages] = useState<SelectedImage[]>([]);
  const [selectedModelId, setSelectedModelId] = useState(DEFAULT_MODEL_ID);
  const [, setImageQuotaRemaining] = useState(5);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatStarted, setChatStarted] = useState(false);
  const [chatId, setChatId] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [isRevealing, setIsRevealing] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [noticeClosing, setNoticeClosing] = useState(false);
  const [reactions, setReactions] = useState<Record<string, MessageReaction>>(
    {},
  );
  const answerTimer = useRef<number | null>(null);
  const revealTimer = useRef<number | null>(null);
  const responseController = useRef<AbortController | null>(null);
  const noticeTimer = useRef<number | null>(null);
  const noticeCloseTimer = useRef<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "end",
    });
  }, [messages, isThinking, isRevealing]);

  useEffect(() => {
    return () => {
      if (answerTimer.current) window.clearTimeout(answerTimer.current);
      if (revealTimer.current) window.clearInterval(revealTimer.current);
      responseController.current?.abort();
      if (noticeTimer.current) window.clearTimeout(noticeTimer.current);
      if (noticeCloseTimer.current)
        window.clearTimeout(noticeCloseTimer.current);
    };
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const saved = localStorage.getItem("megastars:selected-model-id");
      if (saved) setSelectedModelId(saved);
    }, 0);

    function handleModelSelected(event: Event) {
      const detail = (event as CustomEvent<{ id?: string }>).detail;
      if (detail?.id) setSelectedModelId(detail.id);
    }

    window.addEventListener("megastars:model-selected", handleModelSelected);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener(
        "megastars:model-selected",
        handleModelSelected,
      );
    };
  }, []);

  function closeNotice() {
    if (noticeCloseTimer.current) window.clearTimeout(noticeCloseTimer.current);
    setNoticeClosing(true);
    noticeCloseTimer.current = window.setTimeout(() => {
      setNotice(null);
      setNoticeClosing(false);
    }, 260);
  }

  function showNotice(text: string) {
    if (noticeTimer.current) window.clearTimeout(noticeTimer.current);
    if (noticeCloseTimer.current) window.clearTimeout(noticeCloseTimer.current);
    setNoticeClosing(false);
    setNotice(text);
    noticeTimer.current = window.setTimeout(() => closeNotice(), 3200);
  }

  function resetChatState() {
    stopAnswer();
    setChatStarted(false);
    setChatId(null);
    setMessages([]);
    setSelectedImages([]);
    setMessage("");
    setDeepThinking(false);
    setReactions({});
    window.history.replaceState(null, "", "/");
  }

  useEffect(() => {
    function handleNewChat() {
      resetChatState();
    }
    window.addEventListener("megastars:new-chat", handleNewChat);
    return () =>
      window.removeEventListener("megastars:new-chat", handleNewChat);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!requestedChatId) {
      if (chatStarted || chatId || messages.length) {
        const timer = window.setTimeout(() => {
          resetChatState();
        }, 0);
        return () => window.clearTimeout(timer);
      }
      return;
    }

    if (requestedChatId === chatId && chatStarted) return;
    const requested = requestedChatId;
    let active = true;

    async function loadChat() {
      try {
        const response = await fetch(
          `/api/chats/${encodeURIComponent(requested)}`,
          { cache: "no-store" },
        );
        if (!active) return;
        if (!response.ok) {
          resetChatState();
          return;
        }
        const data = await response.json();
        stopAnswer();
        setChatId(data.chat.publicId);
        setMessages((data.messages ?? []).map(normalizeMessage));
        setChatStarted(true);
        setDeepThinking(Boolean(data.chat.deepThinking));
        setMessage("");
        setSelectedImages([]);
      } catch {
        if (!active) return;
        resetChatState();
      }
    }

    void loadChat();
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [requestedChatId]);

  function stopAnswer() {
    if (answerTimer.current) window.clearTimeout(answerTimer.current);
    if (revealTimer.current) window.clearInterval(revealTimer.current);
    answerTimer.current = null;
    revealTimer.current = null;
    responseController.current?.abort();
    responseController.current = null;
    setIsThinking(false);
    setIsRevealing(false);
  }

  async function refreshImageQuota() {
    try {
      const response = await fetch("/api/chats/image-quota", {
        cache: "no-store",
      });
      const data = await response.json().catch(() => null);
      if (!response.ok) {
        if (response.status === 401)
          showNotice("ابتدا اقدام به ساخت حساب/ورود به حساب کنید");
        return null;
      }
      setImageQuotaRemaining(data.remaining ?? 0);
      return Number(data.remaining ?? 0);
    } catch {
      showNotice("بررسی محدودیت آپلود انجام نشد.");
      return null;
    }
  }

  async function openImagePicker() {
    const remaining = await refreshImageQuota();
    if (remaining === null) return;
    if (remaining <= selectedImages.length) {
      showNotice("محدودیت روزانه ۵ عکس تکمیل شده است.");
      return;
    }
    fileInputRef.current?.click();
  }

  async function handleImageSelection(files: FileList | null) {
    if (!files?.length) return;
    const remaining = await refreshImageQuota();
    if (remaining === null) return;
    const available = Math.max(0, remaining - selectedImages.length);
    if (available <= 0) {
      showNotice("محدودیت روزانه ۵ عکس تکمیل شده است.");
      return;
    }

    const picked = Array.from(files)
      .filter((file) =>
        ["image/jpeg", "image/png", "image/webp"].includes(file.type),
      )
      .slice(0, available);

    if (!picked.length) {
      showNotice("فقط عکس با فرمت JPG، PNG یا WEBP پشتیبانی می‌شود.");
      return;
    }
    if (files.length > picked.length)
      showNotice(`حداکثر ${available} عکس دیگر می‌توانید اضافه کنید.`);

    try {
      const images = await Promise.all(picked.map(resizeImage));
      setSelectedImages((current) => [...current, ...images]);
    } catch {
      showNotice("آماده‌سازی عکس انجام نشد.");
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  function removeSelectedImage(localId: string) {
    setSelectedImages((current) =>
      current.filter((image) => image.localId !== localId),
    );
  }

  async function setDeepThinkingMode(nextValue: boolean) {
    setDeepThinking(nextValue);
    if (!chatId) return;
    try {
      const response = await fetch(`/api/chats/${encodeURIComponent(chatId)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deepThinking: nextValue }),
      });
      if (!response.ok) throw new Error("deep_setting_failed");
      const data = await response.json().catch(() => null);
      if (data?.chat) setDeepThinking(Boolean(data.chat.deepThinking));
    } catch {
      setDeepThinking((current) => !current);
      showNotice("ذخیره حالت تفکر عمیق انجام نشد.");
    }
  }

  async function persistUserMessage(text: string) {
    const response = await fetch(
      chatId
        ? `/api/chats/${encodeURIComponent(chatId)}/messages`
        : "/api/chats",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          chatId
            ? {
                role: "user",
                message: text,
                images: selectedImages.map(({ mimeType, data, name }) => ({
                  mimeType,
                  data,
                  name,
                })),
              }
            : {
                message: text,
                modelId: selectedModelId,
                deepThinking,
                images: selectedImages.map(({ mimeType, data, name }) => ({
                  mimeType,
                  data,
                  name,
                })),
              },
        ),
      },
    );

    const data = await response.json().catch(() => null);
    if (!response.ok) {
      if (response.status === 401)
        showNotice("ابتدا اقدام به ساخت حساب/ورود به حساب کنید");
      else showNotice(data?.message ?? "ارسال پیام انجام نشد.");
      return null;
    }

    const nextChatId = chatId ?? data.chat.publicId;
    if (!chatId) {
      setChatId(nextChatId);
      setDeepThinking(Boolean(data.chat.deepThinking));
      window.history.pushState({ chatId: nextChatId }, "", `/?m=${nextChatId}`);
    }

    return { chatId: nextChatId, message: normalizeMessage(data.message) };
  }

  async function copyText(text: string, successMessage = "متن کپی شد.") {
    try {
      await navigator.clipboard.writeText(text);
      showNotice(successMessage);
    } catch {
      const field = document.createElement("textarea");
      field.value = text;
      field.style.position = "fixed";
      field.style.opacity = "0";
      document.body.appendChild(field);
      field.select();
      document.execCommand("copy");
      document.body.removeChild(field);
      showNotice(successMessage);
    }
  }

  async function shareText(text: string) {
    if (navigator.share) {
      try {
        await navigator.share({ text });
        return;
      } catch {
        return;
      }
    }
    await copyText(text, "متن برای اشتراک‌گذاری کپی شد.");
  }

  function toggleReaction(id: string, reaction: MessageReaction) {
    setReactions((current) => {
      const next = { ...current };
      if (next[id] === reaction) delete next[id];
      else next[id] = reaction;
      return next;
    });
  }

  function revealAssistantMessage(fullMessage: ChatMessage) {
    if (revealTimer.current) window.clearInterval(revealTimer.current);
    setIsThinking(false);
    setIsRevealing(true);
    const chunks = createRevealChunks(fullMessage.content);
    let index = 0;
    let visible = "";

    setMessages((current) => [...current, { ...fullMessage, content: "" }]);
    revealTimer.current = window.setInterval(() => {
      const nextChunk = chunks[index];
      if (!nextChunk) {
        if (revealTimer.current) window.clearInterval(revealTimer.current);
        revealTimer.current = null;
        setIsThinking(false);
        setIsRevealing(false);
        return;
      }
      visible += nextChunk;
      index += 1;
      setMessages((current) =>
        current.map((item) =>
          item.id === fullMessage.id ? { ...item, content: visible } : item,
        ),
      );
    }, 115);
  }

  function scheduleChatRefresh(targetChatId: string) {
    [1400, 3600, 6500].forEach((delay) => {
      window.setTimeout(async () => {
        try {
          const response = await fetch(
            `/api/chats/${encodeURIComponent(targetChatId)}`,
            { cache: "no-store" },
          );
          if (!response.ok) return;
          const data = await response.json();
          setChatId(data.chat.publicId);
          setMessages((data.messages ?? []).map(normalizeMessage));
          setChatStarted(true);
        } catch {
          // Silent retry helper for cases where the server saved the answer but the client missed the response.
        }
      }, delay);
    });
  }

  async function persistAssistantMessage(targetChatId: string) {
    const controller = new AbortController();
    responseController.current = controller;

    try {
      const response = await fetch(
        `/api/chats/${encodeURIComponent(targetChatId)}/respond`,
        {
          method: "POST",
          signal: controller.signal,
        },
      );
      const data = await response.json().catch(() => null);
      if (!response.ok) {
        showNotice(data?.message ?? "پاسخ‌گویی هوش مصنوعی موقتاً انجام نشد.");
        return { message: null, aborted: false };
      }
      return { message: normalizeMessage(data.message), aborted: false };
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") {
        return { message: null, aborted: true };
      }
      showNotice("پاسخ‌گویی هوش مصنوعی موقتاً انجام نشد.");
      return { message: null, aborted: false };
    } finally {
      if (responseController.current === controller)
        responseController.current = null;
    }
  }

  async function sendMessage() {
    if (isThinking || isRevealing) {
      stopAnswer();
      return;
    }

    const text = message.trim();
    if (!text && !selectedImages.length) return;

    const saved = await persistUserMessage(text);
    if (!saved) return;

    setChatStarted(true);
    setMessage("");
    setSelectedImages([]);
    void refreshImageQuota();
    setMessages((current) => [...current, saved.message]);
    setIsThinking(true);

    const assistantResult = await persistAssistantMessage(saved.chatId);
    if (assistantResult.aborted) {
      setIsThinking(false);
      return;
    }
    if (assistantResult.message) {
      revealAssistantMessage(assistantResult.message);
      return;
    }
    scheduleChatRefresh(saved.chatId);
    setIsThinking(false);
  }

  return (
    <main
      className="fixed inset-0 overflow-hidden bg-white text-[#101a35] sm:bg-[#f8faff]"
      dir="rtl"
    >
      <div className="mx-auto h-full w-full max-w-[520px] overflow-hidden bg-white shadow-[0_0_55px_rgba(31,65,130,0.08)]">
        <section
          className={`flex h-full min-h-0 flex-col px-5 pb-[calc(1.5rem+env(safe-area-inset-bottom))] sm:px-7 ${chatStarted ? "pt-16" : "pt-24"}`}
        >
          {!chatStarted && (
            <section className="pt-4 text-center">
              <h1 className="text-[23px] font-bold leading-[1.45] text-[#101a35]">
                چی می‌خوای برات انجام بدم؟
              </h1>

              <div className="mt-6 space-y-2" dir="rtl">
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="flex h-11 min-w-0 items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)] transition-transform active:scale-95"
                  >
                    <Clapperboard
                      className="size-5 shrink-0 text-[#e22828]"
                      strokeWidth={1.8}
                    />
                    ویدیو
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="flex h-11 min-w-0 items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)] transition-transform active:scale-95"
                  >
                    <ImagePlus
                      className="size-5 shrink-0 text-[#155eef]"
                      strokeWidth={1.8}
                    />
                    عکس
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="flex h-11 min-w-0 items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)] transition-transform active:scale-95"
                  >
                    <Wrench
                      className="size-5 shrink-0 text-[#f07839]"
                      strokeWidth={1.8}
                    />
                    ابزارها
                  </button>
                </div>
                <div className="flex justify-center gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="flex h-11 w-[47%] items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)] transition-transform active:scale-95"
                  >
                    <Bot
                      className="size-5 shrink-0 text-[#13a538]"
                      strokeWidth={1.8}
                    />
                    دستیارها
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      window.dispatchEvent(new Event("megastars:toast"))
                    }
                    className="flex h-11 w-[47%] items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)] transition-transform active:scale-95"
                  >
                    <Music2
                      className="size-5 shrink-0 text-[#765cf2]"
                      strokeWidth={1.8}
                    />
                    ساخت موزیک
                  </button>
                </div>
              </div>
            </section>
          )}

          {chatStarted && (
            <section className="min-h-0 flex-1 pt-2">
              <div
                className="h-full overflow-y-auto pb-2 pr-0.5 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
                dir="ltr"
              >
                <div className="flex min-h-full flex-col gap-3">
                  {messages.map((item) => {
                    const reaction = reactions[item.id];
                    const isUser = item.role === "user";
                    const attachments = item.attachments ?? [];
                    const visibleContent =
                      isUser &&
                      attachments.length &&
                      item.content.trim() === IMAGE_ONLY_PROMPT
                        ? ""
                        : item.content;
                    return (
                      <div
                        key={item.id}
                        className={`flex animate-[chat-message-in_180ms_ease-out] ${isUser ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`flex min-w-0 max-w-[82%] flex-col ${isUser ? "items-end" : "items-start"}`}
                        >
                          {!!attachments.length && (
                            <div
                              className={`mb-2 grid gap-2 ${attachments.length > 1 ? "grid-cols-2" : "grid-cols-1"}`}
                            >
                              {attachments.map((image, index) => (
                                <div
                                  key={`${item.id}-${index}`}
                                  className="overflow-hidden rounded-2xl border border-[#edf0f6] bg-[#f8faff] shadow-[0_8px_22px_rgba(24,38,75,0.05)]"
                                >
                                  {/* eslint-disable-next-line @next/next/no-img-element */}
                                  <img
                                    src={imageSrc(image)}
                                    alt={image.name ?? "تصویر ارسال‌شده"}
                                    className="max-h-64 max-w-full object-cover"
                                  />
                                </div>
                              ))}
                            </div>
                          )}
                          {visibleContent && (
                            <div
                              dir="auto"
                              className={`${isUser ? "rounded-[20px] rounded-br-md bg-[#101010] px-4 py-3 text-white shadow-[0_8px_22px_rgba(24,38,75,0.06)]" : "px-1 py-1 text-[#202636]"} min-w-0 max-w-full text-sm leading-7`}
                            >
                              <MarkdownText
                                content={visibleContent}
                                inverse={isUser}
                              />
                            </div>
                          )}
                          {visibleContent && (
                            <div
                              className={`mt-1 flex items-center gap-1 ${isUser ? "justify-end" : "justify-start"}`}
                            >
                              <button
                                type="button"
                                aria-label="کپی"
                                onClick={() => void copyText(visibleContent)}
                                className="flex size-7 items-center justify-center rounded-lg text-[#9aa3b5] transition-colors hover:bg-[#f3f6ff] hover:text-[#101a35] active:scale-95"
                              >
                                <Copy className="size-3.5" strokeWidth={1.9} />
                              </button>
                              {!isUser && (
                                <>
                                  <button
                                    type="button"
                                    aria-label="پسندیدن"
                                    onClick={() =>
                                      toggleReaction(item.id, "like")
                                    }
                                    className={`flex size-7 items-center justify-center rounded-lg transition-colors hover:bg-[#f3f6ff] active:scale-95 ${reaction === "like" ? "text-[#13a538]" : "text-[#9aa3b5] hover:text-[#101a35]"}`}
                                  >
                                    <ThumbsUp
                                      className="size-3.5"
                                      strokeWidth={1.9}
                                    />
                                  </button>
                                  <button
                                    type="button"
                                    aria-label="نپسندیدن"
                                    onClick={() =>
                                      toggleReaction(item.id, "dislike")
                                    }
                                    className={`flex size-7 items-center justify-center rounded-lg transition-colors hover:bg-[#f3f6ff] active:scale-95 ${reaction === "dislike" ? "text-[#e22828]" : "text-[#9aa3b5] hover:text-[#101a35]"}`}
                                  >
                                    <ThumbsDown
                                      className="size-3.5"
                                      strokeWidth={1.9}
                                    />
                                  </button>
                                  <button
                                    type="button"
                                    aria-label="اشتراک‌گذاری"
                                    onClick={() =>
                                      void shareText(visibleContent)
                                    }
                                    className="flex size-7 items-center justify-center rounded-lg text-[#9aa3b5] transition-colors hover:bg-[#f3f6ff] hover:text-[#101a35] active:scale-95"
                                  >
                                    <Share2
                                      className="size-3.5"
                                      strokeWidth={1.9}
                                    />
                                  </button>
                                </>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  {isThinking && (
                    <div className="flex animate-[chat-message-in_180ms_ease-out] justify-start">
                      <div
                        className="max-w-[82%] animate-pulse px-1 py-1 text-left text-sm leading-7 text-[#9aa3b5]"
                        dir="ltr"
                      >
                        {deepThinking ? "Deep Thinking..." : "Thinking..."}
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </div>
            </section>
          )}

          <section
            className={
              chatStarted ? "relative z-10 bg-white pt-0" : "mt-auto pt-6"
            }
          >
            <div className="rounded-[22px] border border-[#eee8df] bg-white p-3 shadow-[0_10px_30px_rgba(40,35,25,0.06)]">
              {!!selectedImages.length && (
                <div
                  className="mb-2 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
                  dir="rtl"
                >
                  {selectedImages.map((image) => (
                    <div
                      key={image.localId}
                      className="relative size-16 shrink-0 overflow-hidden rounded-2xl border border-[#edf0f6] bg-[#f8faff]"
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={image.previewUrl}
                        alt={image.name ?? "تصویر انتخاب‌شده"}
                        className="size-full object-cover"
                      />
                      <button
                        type="button"
                        aria-label="حذف عکس"
                        onClick={() => removeSelectedImage(image.localId)}
                        className="absolute left-1 top-1 flex size-5 items-center justify-center rounded-full bg-black/65 text-white shadow-sm active:scale-95"
                      >
                        <X className="size-3" strokeWidth={2.2} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <textarea
                value={message}
                onChange={(event) => setMessage(event.target.value)}
                rows={1}
                placeholder="هرچی میخوای بپرس!"
                className="min-h-12 w-full resize-none bg-transparent px-2 py-2 text-right text-sm text-[#222] outline-none placeholder:text-[#8a8a8a]"
              />
              <div className="mt-2 flex items-center gap-2" dir="ltr">
                <button
                  type="button"
                  aria-label={isThinking || isRevealing ? "توقف" : "ارسال"}
                  onClick={() => void sendMessage()}
                  className={`flex size-9 shrink-0 items-center justify-center rounded-xl text-white transition-[background-color,transform] active:scale-95 ${isThinking || isRevealing || message.trim() || selectedImages.length ? "bg-black" : "bg-[#d9d9d9]"}`}
                >
                  {isThinking || isRevealing ? (
                    <span className="size-3.5 rounded-[4px] border-2 border-white" />
                  ) : (
                    <ArrowUp className="size-5" strokeWidth={2.2} />
                  )}
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  multiple
                  className="hidden"
                  onChange={(event) =>
                    void handleImageSelection(event.target.files)
                  }
                />
                <button
                  type="button"
                  aria-label="پیوست"
                  onClick={() => void openImagePicker()}
                  className="flex size-8 items-center justify-center text-[#141414] transition-transform active:scale-95"
                >
                  <Paperclip className="size-5" strokeWidth={2} />
                </button>
                <button
                  type="button"
                  aria-label="ضبط صدا"
                  className="flex size-8 items-center justify-center text-[#141414] transition-transform active:scale-95"
                >
                  <Mic className="size-5" strokeWidth={2} />
                </button>
                <button
                  type="button"
                  onClick={() => void setDeepThinkingMode(!deepThinking)}
                  className="mr-auto flex items-center gap-2 text-sm text-[#252525]"
                >
                  <span
                    className={`relative h-6 w-10 rounded-full transition-colors duration-200 ${deepThinking ? "bg-black" : "bg-[#d4d8df]"}`}
                  >
                    <span
                      className={`absolute top-1 size-4 rounded-full bg-white shadow-sm transition-transform duration-200 ${deepThinking ? "left-1" : "left-5"}`}
                    />
                  </span>
                  <Sparkles className="size-3.5" strokeWidth={1.8} />
                  <span>تفکر عمیق</span>
                </button>
              </div>
            </div>
            <p className="mt-3 text-center text-[11px] leading-5 text-[#8f8175]">
              هوش مصنوعی ممکن است اشتباه کند؛ اطلاعات مهم را بررسی کنید.
            </p>
          </section>
        </section>

        {notice && (
          <div
            className={`fixed inset-x-0 bottom-[calc(6rem+env(safe-area-inset-bottom))] z-[70] mx-auto w-[calc(100%-32px)] max-w-[488px] ${noticeClosing ? "animate-[toast-out_260ms_ease-in]" : "animate-[toast-in_260ms_ease-out]"}`}
            role="status"
            aria-live="polite"
          >
            <div className="flex items-center gap-3 rounded-2xl bg-[#101a35] px-4 py-3.5 text-white shadow-[0_16px_40px_rgba(16,26,53,0.22)]">
              <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-white/10 text-[#9ebaff]">
                <Bot className="size-5" strokeWidth={1.8} />
              </span>
              <p className="min-w-0 flex-1 text-sm font-bold leading-6">
                {notice}
              </p>
              <button
                type="button"
                onClick={closeNotice}
                className="rounded-lg px-2 py-1 text-xs text-white/60 hover:text-white"
              >
                بستن
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
