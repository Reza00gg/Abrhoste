"use client";

import { ArrowUp, AudioLines, Bot, ImagePlus, Mic, Music2, Paperclip, Sparkles, Clapperboard, Wrench } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [deepThinking, setDeepThinking] = useState(false);
  const [message, setMessage] = useState("");
  return (
    <main className="min-h-dvh bg-[#f8faff] text-[#101a35]" dir="rtl">
      <div className="mx-auto min-h-dvh w-full max-w-[520px] bg-white shadow-[0_0_55px_rgba(31,65,130,0.08)]">
        <section className="flex min-h-dvh flex-col px-5 pb-6 pt-24 sm:px-7">
          <section className="pt-4 text-center">
            <h1 className="text-[23px] font-bold leading-[1.45] text-[#101a35]">
              چی می‌خوای برات انجام بدم؟
            </h1>

            <div className="mt-6 space-y-2" dir="rtl">
              <div className="grid grid-cols-3 gap-3">
                <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="flex h-11 min-w-0 items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)]">
                  <Clapperboard className="size-5 shrink-0 text-[#e22828]" strokeWidth={1.8} />
                  ویدیو
                </button>
                <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="flex h-11 min-w-0 items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)]">
                  <ImagePlus className="size-5 shrink-0 text-[#155eef]" strokeWidth={1.8} />
                  عکس
                </button>
                <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="flex h-11 min-w-0 items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)]">
                  <Wrench className="size-5 shrink-0 text-[#f07839]" strokeWidth={1.8} />
                  ابزارها
                </button>
              </div>
              <div className="flex justify-center gap-3">
                <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="flex h-11 w-[47%] items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)]">
                  <Bot className="size-5 shrink-0 text-[#13a538]" strokeWidth={1.8} />
                  دستیارها
                </button>
                <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="flex h-11 w-[47%] items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)]">
                  <Music2 className="size-5 shrink-0 text-[#765cf2]" strokeWidth={1.8} />
                  ساخت موزیک
                </button>
              </div>
              <div className="flex justify-center">
                <button type="button" onClick={() => window.dispatchEvent(new Event("megastars:toast"))} className="flex h-11 w-[58%] items-center justify-center gap-1.5 overflow-hidden rounded-full border border-[#e9e9e9] bg-white px-1.5 whitespace-nowrap text-[10px] leading-none text-[#626262] shadow-[0_3px_8px_rgba(30,30,30,0.04)]">
                  <AudioLines className="size-5 shrink-0 text-[#d65cf1]" strokeWidth={1.8} />
                  صداگذاری و دوبله
                </button>
              </div>
            </div>
          </section>

          <section className="mt-auto pt-6">
            <div className="rounded-[22px] border border-[#eee8df] bg-white p-3 shadow-[0_10px_30px_rgba(40,35,25,0.06)]">
              <textarea
                value={message}
                onChange={(event) => setMessage(event.target.value)}
                rows={1}
                placeholder="هرچی میخوای بپرس!"
                className="min-h-12 w-full resize-none bg-transparent px-2 py-2 text-right text-sm text-[#222] outline-none placeholder:text-[#8a8a8a]"
              />
              <div className="mt-2 flex items-center gap-2" dir="ltr">
                <button
                  type="button"
                  aria-label="ارسال"
                  className={`flex size-9 shrink-0 items-center justify-center rounded-xl text-white transition-colors active:scale-95 ${message.trim() ? "bg-black" : "bg-[#d9d9d9]"}`}
                >
                  <ArrowUp className="size-5" strokeWidth={2.2} />
                </button>
                <button type="button" aria-label="پیوست" className="flex size-8 items-center justify-center text-[#141414] transition-transform active:scale-95">
                  <Paperclip className="size-5" strokeWidth={2} />
                </button>
                <button type="button" aria-label="ضبط صدا" className="flex size-8 items-center justify-center text-[#141414] transition-transform active:scale-95">
                  <Mic className="size-5" strokeWidth={2} />
                </button>
                <button
                  type="button"
                  onClick={() => setDeepThinking((value) => !value)}
                  className="mr-auto flex items-center gap-2 text-sm text-[#252525]"
                >
                  <span className={`relative h-6 w-10 rounded-full transition-colors duration-200 ${deepThinking ? "bg-black" : "bg-[#d4d8df]"}`}>
                    <span className={`absolute top-1 size-4 rounded-full bg-white shadow-sm transition-transform duration-200 ${deepThinking ? "left-1" : "left-5"}`} />
                  </span>
                  <Sparkles className="size-3.5" strokeWidth={1.8} />
                  <span>تفکر عمیق</span>
                </button>
              </div>
            </div>
            <p className="mt-3 text-center text-[11px] leading-5 text-[#8f8175]">
              هوش مصنوعی ممکن است اشتباه کند؛ اطلاعات مهم را بررسی کنید.
            </p>
          </section>
        </section>


      </div>
    </main>
  );
}
