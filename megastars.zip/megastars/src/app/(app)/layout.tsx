export const dynamic = "force-dynamic";
export const revalidate = 0;

import { AppHeader } from "@/components/app-header";

export default function AppLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div className="min-h-dvh bg-white">
      <AppHeader />
      {children}
    </div>
  );
}
