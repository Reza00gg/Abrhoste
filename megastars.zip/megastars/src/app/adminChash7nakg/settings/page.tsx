import { redirect } from "next/navigation";
import { getAdminUser } from "@/lib/auth";
import { AdminShell } from "@/components/admin/admin-shell";

export const dynamic = "force-dynamic";
export default async function AdminSettings() { const admin = await getAdminUser(); if (!admin) redirect("/adminChash7nakg"); return <AdminShell adminName={admin.name}><h2 className="text-2xl font-bold">تنظیمات</h2><p className="mt-3 text-sm text-white/45">این بخش در فاز بعدی فعال می‌شود.</p></AdminShell>; }
