import { count, ne } from "drizzle-orm";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getAdminUser } from "@/lib/auth";
import { AdminShell } from "@/components/admin/admin-shell";
import { UserList } from "@/components/admin/user-list";

export const dynamic = "force-dynamic";

export default async function AdminUsers() {
  const admin = await getAdminUser();
  if (!admin) redirect("/adminChash7nakg");
  const where = ne(users.role, "admin");
  const [{ total }] = await db.select({ total: count() }).from(users).where(where);
  return <AdminShell adminName={admin.name}><div className="mb-6 flex items-end justify-between"><div><p className="text-sm text-white/40">مدیریت حساب‌ها</p><h2 className="mt-2 text-2xl font-bold">کاربران</h2></div><span className="text-xs text-white/40">{Number(total)} کاربر</span></div><UserList initialUsers={[]} initialTotal={Number(total)} /></AdminShell>;
}
