import { redirect } from "next/navigation";
import { getAdminUser } from "@/lib/auth";
import { AdminShell } from "@/components/admin/admin-shell";
import { AdminModelsList } from "@/components/admin/admin-models-list";

export const dynamic = "force-dynamic";

export default async function AdminModels() {
  const admin = await getAdminUser();
  if (!admin) redirect("/adminChash7nakg");
  return (
    <AdminShell adminName={admin.name}>
      <div className="mb-6">
        <p className="text-sm text-white/40">مدیریت مدل‌های هوش مصنوعی</p>
        <h2 className="mt-2 text-2xl font-bold">مدل‌ها</h2>
        <p className="mt-2 text-xs leading-6 text-white/35">
          مدل‌های فعال، غیرفعال و مخفی پلتفرم را مدیریت کنید.
        </p>
      </div>
      <AdminModelsList />
    </AdminShell>
  );
}
