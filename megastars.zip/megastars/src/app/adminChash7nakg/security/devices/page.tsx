import { redirect } from "next/navigation";
import { getAdminUser } from "@/lib/auth";
import { AdminShell } from "@/components/admin/admin-shell";
import { AdminDevicesList } from "@/components/admin/admin-devices-list";

export const dynamic = "force-dynamic";

export default async function AdminDevicesPage() {
  const admin = await getAdminUser();
  if (!admin) redirect("/adminChash7nakg");
  return <AdminShell adminName={admin.name}><div className="mb-6"><p className="text-sm text-white/40">امنیت پنل مدیریت</p><h2 className="mt-2 text-2xl font-bold">دستگاه‌ها</h2><p className="mt-2 text-xs leading-6 text-white/35">نشست‌های فعال پنل مدیریت را بررسی، خارج یا مسدود کنید.</p></div><AdminDevicesList /></AdminShell>;
}
