import { and, count, eq, isNull, ne } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getAdminUser } from "@/lib/auth";
import { AdminLogin } from "@/components/admin/admin-login";
import { AdminShell } from "@/components/admin/admin-shell";

export const dynamic = "force-dynamic";

export default async function AdminHome() {
  const admin = await getAdminUser();
  if (!admin) return <AdminLogin />;
  const [{ total }] = await db.select({ total: count() }).from(users).where(and(isNull(users.deletedAt), ne(users.role, "admin")));
  const [{ active }] = await db.select({ active: count() }).from(users).where(and(eq(users.status, "active"), ne(users.role, "admin")));
  const [{ inactive }] = await db.select({ inactive: count() }).from(users).where(and(eq(users.status, "inactive"), ne(users.role, "admin")));
  return <AdminShell adminName={admin.name}><div className="mb-8"><p className="text-sm text-white/40">نمای کلی سیستم</p><h2 className="mt-2 text-2xl font-bold">داشبورد</h2></div><div className="grid gap-3 sm:grid-cols-3"><Stat label="کل کاربران" value={total} /><Stat label="کاربران فعال" value={active} tone="green" /><Stat label="غیرفعال" value={inactive} tone="orange" /></div><section className="mt-6 rounded-2xl bg-[#151518] p-4"><h3 className="text-sm font-bold">وضعیت سیستم</h3><div className="mt-4 grid gap-3 sm:grid-cols-3"><Info label="وضعیت دیتابیس" value="متصل" good /><Info label="آخرین ورود ادمین" value={admin.lastLoginAt ? new Date(admin.lastLoginAt).toLocaleString("fa-IR", { timeZone: "Asia/Tehran", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }) : "اولین ورود"} /><Info label="وضعیت سرویس" value="فعال" good /></div></section></AdminShell>;
}

function Stat({ label, value, tone = "blue" }: { label: string; value: number; tone?: string }) {
  const color = tone === "green" ? "text-emerald-400" : tone === "orange" ? "text-orange-300" : "text-blue-300";
  return <div className="rounded-2xl bg-[#151518] p-4"><p className="text-xs text-white/45">{label}</p><p className={`mt-3 text-3xl font-bold ${color}`}>{value}</p></div>;
}
function Info({ label, value, good = false }: { label: string; value: string; good?: boolean }) { return <div className="rounded-xl bg-black/20 p-3"><p className="text-[11px] text-white/40">{label}</p><p className={`mt-2 text-xs ${good ? "text-emerald-400" : "text-white/75"}`}>{value}</p></div>; }
