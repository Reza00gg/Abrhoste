import { NextResponse } from "next/server";
import { getPublicAiModels } from "@/lib/ai-models";

export const dynamic = "force-dynamic";

export async function GET() {
  const items = await getPublicAiModels();
  return NextResponse.json({ items });
}
