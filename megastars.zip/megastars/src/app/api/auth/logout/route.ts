import { NextResponse } from "next/server";
import { destroyCurrentSession, writeAuditLog } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    await destroyCurrentSession();
    await writeAuditLog(null, "logout");
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ message: "خروج از حساب انجام نشد." }, { status: 500 });
  }
}
