import { NextResponse } from "next/server";
import { hash } from "bcryptjs";
import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, writeAuditLog } from "@/lib/auth";
import { registerSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = registerSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ message: parsed.error.issues[0]?.message ?? "اطلاعات واردشده صحیح نیست." }, { status: 400 });
    }

    const { name, identity, password } = parsed.data;
    const isEmail = identity.includes("@");
    const email = isEmail ? identity.toLowerCase() : `${identity}@phone.megastars.local`;
    const phone = isEmail ? null : identity;
    const existing = await db.select({ id: users.id }).from(users).where(or(eq(users.email, email), phone ? eq(users.phone, phone) : undefined)).limit(1);

    if (existing.length) {
      return NextResponse.json({ message: "این ایمیل یا شماره موبایل قبلاً ثبت شده است." }, { status: 409 });
    }

    const passwordHash = await hash(password, 12);
    const [user] = await db.insert(users).values({ name, email, phone, passwordHash }).returning({ id: users.id });
    await createSession(user.id);
    await writeAuditLog(user.id, "register");

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ message: "خطایی در ساخت حساب رخ داد." }, { status: 500 });
  }
}
