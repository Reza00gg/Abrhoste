import { NextResponse } from "next/server";
import { compare } from "bcryptjs";
import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, writeAuditLog } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = loginSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ message: parsed.error.issues[0]?.message ?? "اطلاعات ورود کامل نیست." }, { status: 400 });
    }

    const { identity, password } = parsed.data;
    const normalized = identity.includes("@") ? identity.toLowerCase() : identity;
    const emailIdentity = identity.includes("@") ? normalized : `${normalized}@phone.megastars.local`;
    const [user] = await db.select().from(users).where(or(eq(users.email, emailIdentity), eq(users.phone, normalized))).limit(1);
    const valid = user && user.status === "active" && !user.deletedAt && await compare(password, user.passwordHash);

    if (!valid) {
      await writeAuditLog(user?.id ?? null, "login", false);
      return NextResponse.json({ message: "ایمیل یا رمز عبور صحیح نیست." }, { status: 401 });
    }

    await db.update(users).set({ lastLoginAt: new Date(), updatedAt: new Date() }).where(eq(users.id, user.id));
    await createSession(user.id);
    await writeAuditLog(user.id, "login");

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ message: "خطایی در ورود رخ داد." }, { status: 500 });
  }
}
