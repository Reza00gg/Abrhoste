import { and, desc, eq, gt } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { getAdminSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

function parseDevice(userAgent: string | null) {
  const value = userAgent ?? "";
  const browser = value.includes("Edg/") ? "Microsoft Edge"
    : value.includes("Chrome/") ? "Chrome"
      : value.includes("Firefox/") ? "Firefox"
        : value.includes("Safari/") ? "Safari"
          : "نامشخص";
  const os = value.includes("Android") ? "Android"
    : value.includes("iPhone") || value.includes("iPad") ? "iOS"
      : value.includes("Windows") ? "Windows"
        : value.includes("Mac OS") ? "macOS"
          : value.includes("Linux") ? "Linux"
            : "نامشخص";
  const device = value.includes("Mobile") || value.includes("Android") || value.includes("iPhone") ? "موبایل" : "دسکتاپ";
  return { browser, os, device };
}

export async function GET() {
  const current = await getAdminSession();
  if (!current) return NextResponse.json({ message: "دسترسی غیرمجاز است." }, { status: 403 });

  const rows = await db
    .select({
      id: sessions.id,
      adminName: users.name,
      adminEmail: users.email,
      ipAddress: sessions.ipAddress,
      userAgent: sessions.userAgent,
      createdAt: sessions.createdAt,
      lastUsedAt: sessions.lastUsedAt,
      expiresAt: sessions.expiresAt,
    })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.type, "admin"), eq(users.role, "admin"), eq(users.status, "active"), gt(sessions.expiresAt, new Date())))
    .orderBy(desc(sessions.lastUsedAt));

  return NextResponse.json({
    items: rows.map((row) => ({
      ...row,
      ...parseDevice(row.userAgent),
      isCurrent: row.id === current.session.id,
    })),
  });
}
