import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { adminDeviceBlocks, sessions, users } from "@/db/schema";
import { getAdminSession, writeAuditLog } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const current = await getAdminSession();
  if (!current) return NextResponse.json({ message: "دسترسی غیرمجاز است." }, { status: 403 });

  const { id } = await params;
  const [target] = await db
    .select({ id: sessions.id, ipAddress: sessions.ipAddress, userAgent: sessions.userAgent, userRole: users.role })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.id, id), eq(sessions.type, "admin"), eq(users.role, "admin")))
    .limit(1);

  if (!target) return NextResponse.json({ message: "دستگاه پیدا نشد." }, { status: 404 });
  if (!target.ipAddress || !target.userAgent) return NextResponse.json({ message: "اطلاعات دستگاه کامل نیست." }, { status: 400 });

  const existing = await db
    .select({ id: adminDeviceBlocks.id })
    .from(adminDeviceBlocks)
    .where(and(eq(adminDeviceBlocks.ipAddress, target.ipAddress), eq(adminDeviceBlocks.userAgent, target.userAgent)))
    .limit(1);

  if (!existing.length) {
    await db.insert(adminDeviceBlocks).values({
      blockedById: current.user.id,
      ipAddress: target.ipAddress,
      userAgent: target.userAgent,
    });
  }

  await db.delete(sessions).where(eq(sessions.id, id));
  await writeAuditLog(current.user.id, "admin_device_blocked", true, { targetSessionId: id, ipAddress: target.ipAddress });
  return NextResponse.json({ ok: true, blockedCurrent: id === current.session.id });
}
