import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { getAdminSession, writeAuditLog } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const current = await getAdminSession();
  if (!current) return NextResponse.json({ message: "دسترسی غیرمجاز است." }, { status: 403 });

  const { id } = await params;
  const [target] = await db
    .select({ id: sessions.id, type: sessions.type, userRole: users.role })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.id, id), eq(sessions.type, "admin"), eq(users.role, "admin")))
    .limit(1);

  if (!target) return NextResponse.json({ message: "دستگاه پیدا نشد." }, { status: 404 });

  await db.delete(sessions).where(eq(sessions.id, id));
  await writeAuditLog(current.user.id, "admin_device_kicked", true, { targetSessionId: id });
  return NextResponse.json({ ok: true, kickedCurrent: id === current.session.id });
}
