import { NextResponse } from "next/server";
import { destroyAdminSession, writeAuditLog } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST() {
  await destroyAdminSession();
  await writeAuditLog(null, "admin_logout");
  return NextResponse.json({ ok: true });
}
