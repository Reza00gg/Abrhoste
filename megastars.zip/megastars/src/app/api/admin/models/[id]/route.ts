import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { aiModels } from "@/db/schema";
import { getAdminUser } from "@/lib/auth";
import { encryptModelSecret, maskModelSecret } from "@/lib/model-secrets";

export const dynamic = "force-dynamic";

function normalizeStatus(value: unknown) {
  return ["active", "inactive", "hidden"].includes(String(value))
    ? String(value)
    : "active";
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAdminUser();
  if (!admin)
    return NextResponse.json(
      { message: "دسترسی غیرمجاز است." },
      { status: 403 },
    );

  const { id } = await params;
  const body = await request.json().catch(() => null);
  const name = String(body?.name ?? "").trim();
  const apiModel = String(body?.apiModel ?? "").trim();
  const apiKey = String(body?.apiKey ?? "").trim();
  const icon = String(body?.icon ?? "").trim() || null;
  const status = normalizeStatus(body?.status);

  if (name.length < 2)
    return NextResponse.json(
      { message: "اسم مدل را کامل وارد کنید." },
      { status: 400 },
    );
  if (apiModel.length < 3)
    return NextResponse.json(
      { message: "API مدل را کامل وارد کنید." },
      { status: 400 },
    );

  const values: Partial<typeof aiModels.$inferInsert> = {
    name,
    apiModel,
    icon,
    status,
    updatedAt: new Date(),
  };
  if (apiKey) values.apiKeyEncrypted = encryptModelSecret(apiKey);

  const [model] = await db
    .update(aiModels)
    .set(values)
    .where(eq(aiModels.id, id))
    .returning();
  if (!model)
    return NextResponse.json({ message: "مدل پیدا نشد." }, { status: 404 });

  return NextResponse.json({
    item: {
      id: model.id,
      name: model.name,
      apiModel: model.apiModel,
      status: model.status,
      builtIn: false,
      icon: model.icon,
      apiKeyMasked: maskModelSecret(apiKey || "saved-key"),
      lastTestAt: model.lastTestAt,
      lastTestMessage: model.lastTestMessage,
      createdAt: model.createdAt,
      updatedAt: model.updatedAt,
    },
  });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAdminUser();
  if (!admin)
    return NextResponse.json(
      { message: "دسترسی غیرمجاز است." },
      { status: 403 },
    );

  const { id } = await params;
  const [deleted] = await db
    .delete(aiModels)
    .where(eq(aiModels.id, id))
    .returning({ id: aiModels.id });
  if (!deleted)
    return NextResponse.json({ message: "مدل پیدا نشد." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
