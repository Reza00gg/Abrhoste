import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { aiModels } from "@/db/schema";
import { getAdminUser } from "@/lib/auth";
import { encryptModelSecret, maskModelSecret } from "@/lib/model-secrets";

export const dynamic = "force-dynamic";

const builtInModel = {
  id: "system-gemini-3-1-flash-lite",
  name: "Gemini 3.1 Flash Lite",
  apiModel: "gemini-3.1-flash-lite",
  status: "active",
  builtIn: true,
  icon: "gemini",
  apiKeyMasked: "ENV",
  lastTestAt: null,
  lastTestMessage: "مدل داخلی فعال پلتفرم",
  createdAt: null,
  updatedAt: null,
};

function normalizeStatus(value: unknown) {
  return ["active", "inactive", "hidden"].includes(String(value))
    ? String(value)
    : "active";
}

export async function GET() {
  const admin = await getAdminUser();
  if (!admin)
    return NextResponse.json(
      { message: "دسترسی غیرمجاز است." },
      { status: 403 },
    );

  const rows = await db
    .select()
    .from(aiModels)
    .orderBy(desc(aiModels.updatedAt));
  return NextResponse.json({
    items: [
      builtInModel,
      ...rows.map((item) => ({
        id: item.id,
        name: item.name,
        apiModel: item.apiModel,
        status: item.status,
        builtIn: false,
        icon: item.icon,
        apiKeyMasked: maskModelSecret("saved-key"),
        lastTestAt: item.lastTestAt,
        lastTestMessage: item.lastTestMessage,
        createdAt: item.createdAt,
        updatedAt: item.updatedAt,
      })),
    ],
  });
}

export async function POST(request: Request) {
  const admin = await getAdminUser();
  if (!admin)
    return NextResponse.json(
      { message: "دسترسی غیرمجاز است." },
      { status: 403 },
    );

  const body = await request.json().catch(() => null);
  const name = String(body?.name ?? "").trim();
  const apiModel = String(body?.apiModel ?? "").trim();
  const apiKey = String(body?.apiKey ?? "").trim();
  const icon = String(body?.icon ?? "").trim() || null;
  const status = normalizeStatus(body?.status);

  if (name.length < 2)
    return NextResponse.json(
      { message: "اسم مدل را کامل وارد کنید." },
      { status: 400 },
    );
  if (apiModel.length < 3)
    return NextResponse.json(
      { message: "API مدل را کامل وارد کنید." },
      { status: 400 },
    );
  if (apiKey.length < 8)
    return NextResponse.json(
      { message: "API Key را کامل وارد کنید." },
      { status: 400 },
    );

  const [model] = await db
    .insert(aiModels)
    .values({
      name,
      apiModel,
      apiKeyEncrypted: encryptModelSecret(apiKey),
      icon,
      status,
      lastTestAt: new Date(),
      lastTestMessage: "اتصال قبل از افزودن تست شد.",
    })
    .returning();

  return NextResponse.json({
    item: {
      id: model.id,
      name: model.name,
      apiModel: model.apiModel,
      status: model.status,
      builtIn: false,
      icon: model.icon,
      apiKeyMasked: maskModelSecret(apiKey),
      lastTestAt: model.lastTestAt,
      lastTestMessage: model.lastTestMessage,
      createdAt: model.createdAt,
      updatedAt: model.updatedAt,
    },
  });
}
