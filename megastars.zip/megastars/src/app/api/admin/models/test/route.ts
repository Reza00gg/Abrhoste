import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { aiModels } from "@/db/schema";
import { getAdminUser } from "@/lib/auth";
import { testAiModelConnection } from "@/lib/ai-model-testing";
import { decryptModelSecret } from "@/lib/model-secrets";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const admin = await getAdminUser();
  if (!admin)
    return NextResponse.json(
      { message: "دسترسی غیرمجاز است." },
      { status: 403 },
    );

  const body = await request.json().catch(() => null);
  const id = String(body?.id ?? "").trim();
  const apiModel = String(body?.apiModel ?? "").trim();
  let apiKey = String(body?.apiKey ?? "").trim();

  if (id && !apiKey) {
    const [model] = await db
      .select()
      .from(aiModels)
      .where(eq(aiModels.id, id))
      .limit(1);
    if (!model)
      return NextResponse.json({ message: "مدل پیدا نشد." }, { status: 404 });
    apiKey = decryptModelSecret(model.apiKeyEncrypted);
  }

  const result = await testAiModelConnection(apiModel, apiKey);
  return NextResponse.json(result, { status: result.ok ? 200 : 400 });
}
