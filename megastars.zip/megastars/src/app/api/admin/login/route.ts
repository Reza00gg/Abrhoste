import { compare } from "bcryptjs";
import { and, count, eq, gte } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { auditLogs, users } from "@/db/schema";
import { createAdminSession, getRequestClientInfo, isAdminClientBlocked, writeAuditLog } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

const UNAUTHORIZED_MESSAGE = "دسترسی غیرمجاز است.";
const DUMMY_ADMIN_PASSWORD_HASH = "$2b$12$KNyfgVLkN0c2TLFB/zbLsuNYd0w.LI45h/tpQxDpNWdLVstPG4a7S";
const ADMIN_LOGIN_WINDOW_MS = 10 * 60 * 1000;
const MAX_FAILED_ADMIN_ATTEMPTS = 8;

async function hasTooManyFailedAttempts(ipAddress: string | null) {
  if (!ipAddress) return false;
  const since = new Date(Date.now() - ADMIN_LOGIN_WINDOW_MS);
  const [{ total }] = await db
    .select({ total: count() })
    .from(auditLogs)
    .where(and(eq(auditLogs.event, "admin_login"), eq(auditLogs.success, false), eq(auditLogs.ipAddress, ipAddress), gte(auditLogs.createdAt, since)));
  return Number(total) >= MAX_FAILED_ADMIN_ATTEMPTS;
}

function unauthorized(status = 401) {
  return NextResponse.json({ message: UNAUTHORIZED_MESSAGE }, { status });
}

export async function POST(request: Request) {
  try {
    const clientInfo = await getRequestClientInfo();

    if (await isAdminClientBlocked()) {
      await writeAuditLog(null, "admin_login_blocked", false, { reason: "blocked_device" });
      return unauthorized(403);
    }

    if (await hasTooManyFailedAttempts(clientInfo.ipAddress)) {
      await writeAuditLog(null, "admin_login_blocked", false, { reason: "rate_limited" });
      return unauthorized(429);
    }

    const parsed = loginSchema.safeParse(await request.json());
    if (!parsed.success) {
      await writeAuditLog(null, "admin_login_invalid_payload", false, { reason: "invalid_payload" });
      return NextResponse.json({ message: "اطلاعات ورود کامل نیست." }, { status: 400 });
    }

    const identity = parsed.data.identity.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identity)) {
      await writeAuditLog(null, "admin_login", false, { reason: "invalid_identity" });
      return unauthorized();
    }

    const [user] = await db.select().from(users).where(eq(users.email, identity)).limit(1);
    const passwordValid = await compare(parsed.data.password, user?.passwordHash ?? DUMMY_ADMIN_PASSWORD_HASH);
    const valid = Boolean(user && user.role === "admin" && user.status === "active" && !user.deletedAt && passwordValid);

    if (!valid) {
      await writeAuditLog(user?.id ?? null, "admin_login", false, { reason: "invalid_credentials" });
      return unauthorized();
    }

    await createAdminSession(user.id);
    await db.update(users).set({ lastLoginAt: new Date(), updatedAt: new Date() }).where(eq(users.id, user.id));
    await writeAuditLog(user.id, "admin_login");
    return NextResponse.json({ ok: true });
  } catch {
    return unauthorized();
  }
}
