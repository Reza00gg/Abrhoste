import { compare } from "bcryptjs";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createAdminSession, writeAuditLog } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const parsed = loginSchema.safeParse(await request.json());
    if (!parsed.success) return NextResponse.json({ message: "اطلاعات ورود کامل نیست." }, { status: 400 });
    const identity = parsed.data.identity.toLowerCase();
    const [user] = await db.select().from(users).where(eq(users.email, identity)).limit(1);
    const valid = user && user.role === "admin" && user.status === "active" && !user.deletedAt && await compare(parsed.data.password, user.passwordHash);
    if (!valid) {
      await writeAuditLog(user?.id ?? null, "admin_login", false);
      return NextResponse.json({ message: "اطلاعات ورود ادمین صحیح نیست." }, { status: 401 });
    }
    await createAdminSession(user.id);
    await db.update(users).set({ lastLoginAt: new Date(), updatedAt: new Date() }).where(eq(users.id, user.id));
    await writeAuditLog(user.id, "admin_login");
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ message: "خطایی در ورود ادمین رخ داد." }, { status: 500 });
  }
}
