import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { auditLogs, users } from "@/db/schema";
import { getAdminUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await getAdminUser();
  if (!admin)
    return NextResponse.json(
      { message: "دسترسی غیرمجاز است." },
      { status: 403 },
    );
  const { id } = await params;
  const [target] = await db
    .select({ role: users.role })
    .from(users)
    .where(eq(users.id, id))
    .limit(1);
  if (!target || target.role === "admin")
    return NextResponse.json(
      { message: "کاربر قابل ریست نیست." },
      { status: 403 },
    );
  await db
    .insert(auditLogs)
    .values({
      userId: admin.id,
      event: "admin_user_reset",
      metadata: { targetUserId: id, reset: ["daily_image_quota"] },
    });
  return NextResponse.json({ ok: true });
}
