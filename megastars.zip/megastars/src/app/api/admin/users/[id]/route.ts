import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getAdminUser, writeAuditLog } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const admin = await getAdminUser();
  if (!admin) return NextResponse.json({ message: "دسترسی غیرمجاز است." }, { status: 403 });
  const { id } = await params;
  const [target] = await db.select({ role: users.role }).from(users).where(eq(users.id, id)).limit(1);
  if (target?.role === "admin") return NextResponse.json({ message: "حساب‌های ادمین از این بخش قابل تغییر نیستند." }, { status: 403 });
  const body = await request.json();
  if (!["active", "inactive"].includes(body.status)) return NextResponse.json({ message: "وضعیت نامعتبر است." }, { status: 400 });
  await db.update(users).set({ status: body.status, deletedAt: body.status === "active" ? null : undefined, updatedAt: new Date() }).where(eq(users.id, id));
  await writeAuditLog(admin.id, `admin_user_${body.status}`);
  return NextResponse.json({ ok: true });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const admin = await getAdminUser();
  if (!admin) return NextResponse.json({ message: "دسترسی غیرمجاز است." }, { status: 403 });
  const { id } = await params;
  const [target] = await db.select({ role: users.role }).from(users).where(eq(users.id, id)).limit(1);
  if (target?.role === "admin") return NextResponse.json({ message: "حساب‌های ادمین از این بخش قابل حذف نیستند." }, { status: 403 });
  if (new URL(_request.url).searchParams.get("permanent") === "1") {
    await db.delete(users).where(eq(users.id, id));
  } else {
    await db.update(users).set({ deletedAt: new Date(), status: "inactive", updatedAt: new Date() }).where(eq(users.id, id));
  }
  await writeAuditLog(admin.id, "admin_user_deleted");
  return NextResponse.json({ ok: true });
}
