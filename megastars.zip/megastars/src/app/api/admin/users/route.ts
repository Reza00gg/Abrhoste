import { and, count, desc, eq, ilike, isNull, ne, not, or } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getAdminUser } from "@/lib/auth";

export const dynamic = "force-dynamic";
const PAGE_SIZE = 8;

export async function GET(request: Request) {
  const admin = await getAdminUser();
  if (!admin) return NextResponse.json({ message: "دسترسی غیرمجاز است." }, { status: 403 });
  const url = new URL(request.url);
  const page = Math.max(1, Number(url.searchParams.get("page") || 1));
  const tab = url.searchParams.get("tab") || "all";
  const search = url.searchParams.get("search")?.trim() || "";
  const statusCondition = tab === "active" ? and(eq(users.status, "active"), isNull(users.deletedAt)) : tab === "inactive" ? and(ne(users.status, "active"), isNull(users.deletedAt)) : tab === "deleted" ? undefined : isNull(users.deletedAt);
  const conditions = [ne(users.role, "admin"), statusCondition, search ? or(ilike(users.name, `%${search}%`), ilike(users.email, `%${search}%`)) : undefined].filter(Boolean);
  const where = and(...conditions);
  const [{ total }] = await db.select({ total: count() }).from(users).where(where);
  const items = await db.select({ id: users.id, name: users.name, email: users.email, phone: users.phone, status: users.status, role: users.role, deletedAt: users.deletedAt, createdAt: users.createdAt, lastLoginAt: users.lastLoginAt }).from(users).where(where).orderBy(desc(users.createdAt)).limit(PAGE_SIZE).offset((page - 1) * PAGE_SIZE);
  const [{ active }] = await db.select({ active: count() }).from(users).where(and(ne(users.role, "admin"), eq(users.status, "active"), isNull(users.deletedAt)));
  const [{ inactive }] = await db.select({ inactive: count() }).from(users).where(and(ne(users.role, "admin"), ne(users.status, "active"), isNull(users.deletedAt)));
  const [{ deleted }] = await db.select({ deleted: count() }).from(users).where(and(ne(users.role, "admin"), not(isNull(users.deletedAt))));
  return NextResponse.json({ items, total, counts: { all: Number(active) + Number(inactive), active, inactive, deleted }, page, totalPages: Math.max(1, Math.ceil(Number(total) / PAGE_SIZE)) });
}
