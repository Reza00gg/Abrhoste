import { randomInt } from "node:crypto";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { chatConversations, chatMessages } from "@/db/schema";
import { ensureImageQuota, normalizeImageAttachments } from "@/lib/chat-images";
import { BUILTIN_MODEL_ID, isSelectableModel } from "@/lib/ai-models";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

function createTitle(content: string) {
  const normalized = content.replace(/\s+/g, " ").trim();
  return normalized.length > 60
    ? `${normalized.slice(0, 57)}...`
    : normalized || "چت جدید";
}

async function createUniquePublicId() {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const publicId = String(randomInt(1000000, 10000000));
    const existing = await db
      .select({ id: chatConversations.id })
      .from(chatConversations)
      .where(eq(chatConversations.publicId, publicId))
      .limit(1);
    if (!existing.length) return publicId;
  }
  return `${Date.now()}${randomInt(100, 999)}`;
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ items: [] }, { status: 401 });

  const items = await db
    .select({
      publicId: chatConversations.publicId,
      title: chatConversations.title,
      modelId: chatConversations.modelId,
      deepThinking: chatConversations.deepThinking,
      updatedAt: chatConversations.updatedAt,
      createdAt: chatConversations.createdAt,
    })
    .from(chatConversations)
    .where(eq(chatConversations.userId, user.id))
    .orderBy(desc(chatConversations.updatedAt))
    .limit(20);

  return NextResponse.json({ items });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user)
    return NextResponse.json(
      { message: "ابتدا اقدام به ساخت حساب/ورود به حساب کنید" },
      { status: 401 },
    );

  const body = await request.json().catch(() => null);
  const requestedModelId = String(body?.modelId ?? BUILTIN_MODEL_ID).trim();
  const modelId = (await isSelectableModel(requestedModelId))
    ? requestedModelId
    : BUILTIN_MODEL_ID;
  const deepThinking = Boolean(body?.deepThinking);
  const attachments = normalizeImageAttachments(body?.images);
  const content =
    String(body?.message ?? "").trim() ||
    (attachments.length ? "این تصویر را تحلیل کن." : "");
  if (!content)
    return NextResponse.json(
      { message: "پیام را وارد کنید." },
      { status: 400 },
    );
  if (content.length > 4000)
    return NextResponse.json(
      { message: "پیام بیش از حد طولانی است." },
      { status: 400 },
    );

  if (attachments.length) {
    const quota = await ensureImageQuota(user.id, attachments.length);
    if (!quota.allowed) {
      return NextResponse.json(
        {
          message: `امروز فقط ${quota.remaining} عکس دیگر می‌توانید ارسال کنید.`,
        },
        { status: 429 },
      );
    }
  }

  const publicId = await createUniquePublicId();
  const [conversation] = await db
    .insert(chatConversations)
    .values({
      publicId,
      userId: user.id,
      title: createTitle(content),
      modelId,
      deepThinking,
    })
    .returning({
      id: chatConversations.id,
      publicId: chatConversations.publicId,
      title: chatConversations.title,
      modelId: chatConversations.modelId,
      deepThinking: chatConversations.deepThinking,
    });

  const [message] = await db
    .insert(chatMessages)
    .values({
      conversationId: conversation.id,
      role: "user",
      content,
      attachments,
    })
    .returning({
      id: chatMessages.id,
      role: chatMessages.role,
      content: chatMessages.content,
      attachments: chatMessages.attachments,
      createdAt: chatMessages.createdAt,
    });

  return NextResponse.json({
    chat: {
      publicId: conversation.publicId,
      title: conversation.title,
      modelId: conversation.modelId,
      deepThinking: conversation.deepThinking,
    },
    message,
  });
}
