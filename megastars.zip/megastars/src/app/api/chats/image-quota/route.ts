import { NextResponse } from "next/server";
import { getImageQuota } from "@/lib/chat-images";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user)
    return NextResponse.json(
      { message: "ابتدا اقدام به ساخت حساب/ورود به حساب کنید" },
      { status: 401 },
    );
  const quota = await getImageQuota(user.id);
  return NextResponse.json(quota);
}
