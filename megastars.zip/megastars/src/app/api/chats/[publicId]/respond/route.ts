import { and, asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { chatConversations, chatMessages } from "@/db/schema";
import { getModelRuntime } from "@/lib/ai-models";
import { getCurrentUser } from "@/lib/auth";
import {
  MEGACHAT_DEEP_THINKING_PROMPT,
  MEGACHAT_SYSTEM_PROMPT,
} from "@/lib/megachat-system-prompt";
import {
  normalizeImageAttachments,
  type ChatImageAttachment,
} from "@/lib/chat-images";

export const dynamic = "force-dynamic";

const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-3.1-flash-lite";
const GEMINI_DEEP_MODEL =
  process.env.GEMINI_DEEP_MODEL || "gemini-3.5-flash-lite";
type GeminiPart = {
  text?: string;
  inlineData?: { mimeType: string; data: string };
};
type GeminiContent = { role?: string; parts?: GeminiPart[] };
type GeminiResponse = {
  candidates?: Array<{ content?: GeminiContent; finishReason?: string }>;
  error?: { message?: string; status?: string; code?: number };
};

function toGeminiRole(role: string) {
  return role === "assistant" ? "model" : "user";
}

function extractGeminiText(data: GeminiResponse) {
  const parts = data.candidates?.[0]?.content?.parts ?? [];
  return parts
    .map((part) => part.text ?? "")
    .join("\n")
    .trim();
}

function isGoogleModel(value: string) {
  return (
    !value.startsWith("http") ||
    value.includes("generativelanguage.googleapis.com")
  );
}

function resolveGeminiEndpoint(model: string) {
  if (model.startsWith("http")) return model;
  return `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
}

function resolveOpenAiTarget(apiModel: string) {
  if (apiModel.includes("|")) {
    const [endpoint, model] = apiModel.split("|").map((part) => part.trim());
    return { endpoint, model };
  }
  return { endpoint: apiModel, model: "default" };
}

async function generateGeminiReply(
  history: Array<{ role: string; content: string; attachments?: unknown }>,
  deepThinking: boolean,
  apiModel: string,
  apiKey: string,
  allowDeepModelFallback: boolean,
) {
  if (!apiKey) throw new Error("AI model API key is not configured");

  const contents = history.slice(deepThinking ? -36 : -24).map((message) => {
    const attachments = normalizeImageAttachments(message.attachments);
    const parts: GeminiPart[] = [
      {
        text:
          message.content ||
          (attachments.length ? "این تصویر را تحلیل کن." : ""),
      },
    ];
    attachments.forEach((image: ChatImageAttachment) => {
      parts.push({
        inlineData: { mimeType: image.mimeType, data: image.data },
      });
    });
    return { role: toGeminiRole(message.role), parts };
  });

  const systemPrompt = deepThinking
    ? `${MEGACHAT_SYSTEM_PROMPT}

${MEGACHAT_DEEP_THINKING_PROMPT}`
    : MEGACHAT_SYSTEM_PROMPT;
  const modelCandidates =
    allowDeepModelFallback && deepThinking
      ? Array.from(new Set([GEMINI_DEEP_MODEL, GEMINI_MODEL]))
      : [apiModel];
  let lastError = "Gemini request failed";

  for (const model of modelCandidates) {
    const workingContents = [...contents];
    const chunks: string[] = [];
    const maxContinuations = deepThinking ? 3 : 2;

    for (
      let continuation = 0;
      continuation <= maxContinuations;
      continuation += 1
    ) {
      const response = await fetch(resolveGeminiEndpoint(model), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: systemPrompt }],
          },
          contents: workingContents,
          generationConfig: {
            temperature: deepThinking ? 0.5 : 0.7,
            topP: deepThinking ? 0.82 : 0.9,
            maxOutputTokens: deepThinking ? 14000 : 7000,
          },
        }),
      });

      const data = (await response.json().catch(() => ({}))) as GeminiResponse;
      if (!response.ok) {
        lastError = data.error?.message || `Gemini request failed: ${model}`;
        break;
      }

      const text = extractGeminiText(data);
      if (text) chunks.push(text);

      if (data.candidates?.[0]?.finishReason !== "MAX_TOKENS") {
        const finalText = chunks.join("\n").trim();
        return finalText || "متوجه نشدم؛ لطفاً دوباره بپرس.";
      }

      workingContents.push({ role: "model", parts: [{ text }] });
      workingContents.push({
        role: "user",
        parts: [
          {
            text: "ادامه بده دقیقاً از همان جایی که قطع شد. متن یا کد را تکرار نکن. اگر داخل code block هستی، همان code block را کامل ادامه بده و در پایان درست ببند.",
          },
        ],
      });
    }

    if (chunks.length) return chunks.join("\n").trim();
  }

  throw new Error(lastError);
}

async function generateOpenAiCompatibleReply(
  history: Array<{ role: string; content: string; attachments?: unknown }>,
  deepThinking: boolean,
  apiModel: string,
  apiKey: string,
) {
  const { endpoint, model } = resolveOpenAiTarget(apiModel);
  const messages = history.slice(deepThinking ? -36 : -24).map((message) => ({
    role: message.role === "assistant" ? "assistant" : "user",
    content: message.content || "این تصویر را تحلیل کن.",
  }));
  messages.unshift({
    role: "system",
    content: deepThinking
      ? `${MEGACHAT_SYSTEM_PROMPT}

${MEGACHAT_DEEP_THINKING_PROMPT}`
      : MEGACHAT_SYSTEM_PROMPT,
  });

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: deepThinking ? 0.5 : 0.7,
      max_tokens: deepThinking ? 6000 : 2500,
    }),
  });
  const data = await response.json().catch(() => null);
  if (!response.ok)
    throw new Error(data?.error?.message ?? "AI model request failed");
  return (
    data?.choices?.[0]?.message?.content?.trim() ||
    "متوجه نشدم؛ لطفاً دوباره بپرس."
  );
}

async function generateRuntimeReply(
  history: Array<{ role: string; content: string; attachments?: unknown }>,
  deepThinking: boolean,
  modelId: string,
) {
  const runtime = await getModelRuntime(modelId);
  const selected =
    runtime ?? (await getModelRuntime("system-gemini-3-1-flash-lite"));
  if (!selected) throw new Error("No available AI model runtime");

  if (isGoogleModel(selected.apiModel)) {
    return generateGeminiReply(
      history,
      deepThinking,
      selected.apiModel,
      selected.apiKey,
      selected.builtIn,
    );
  }

  return generateOpenAiCompatibleReply(
    history,
    deepThinking,
    selected.apiModel,
    selected.apiKey,
  );
}

export async function POST(
  _request: Request,
  { params }: { params: Promise<{ publicId: string }> },
) {
  const user = await getCurrentUser();
  if (!user)
    return NextResponse.json(
      { message: "ابتدا اقدام به ساخت حساب/ورود به حساب کنید" },
      { status: 401 },
    );

  const { publicId } = await params;
  const [chat] = await db
    .select({
      id: chatConversations.id,
      modelId: chatConversations.modelId,
      deepThinking: chatConversations.deepThinking,
    })
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.publicId, publicId),
        eq(chatConversations.userId, user.id),
      ),
    )
    .limit(1);

  if (!chat)
    return NextResponse.json({ message: "چت پیدا نشد." }, { status: 404 });

  const history = await db
    .select({
      role: chatMessages.role,
      content: chatMessages.content,
      attachments: chatMessages.attachments,
    })
    .from(chatMessages)
    .where(eq(chatMessages.conversationId, chat.id))
    .orderBy(asc(chatMessages.createdAt));

  if (!history.length || history[history.length - 1]?.role !== "user") {
    return NextResponse.json(
      { message: "پیام جدیدی برای پاسخ وجود ندارد." },
      { status: 400 },
    );
  }

  try {
    const reply = await generateRuntimeReply(
      history,
      chat.deepThinking,
      chat.modelId,
    );
    const [message] = await db
      .insert(chatMessages)
      .values({ conversationId: chat.id, role: "assistant", content: reply })
      .returning({
        id: chatMessages.id,
        role: chatMessages.role,
        content: chatMessages.content,
        createdAt: chatMessages.createdAt,
      });

    await db
      .update(chatConversations)
      .set({ updatedAt: new Date() })
      .where(eq(chatConversations.id, chat.id));
    return NextResponse.json({ message });
  } catch (error) {
    console.error(
      "megachat_respond_failed",
      error instanceof Error ? error.message : String(error),
    );
    return NextResponse.json(
      { message: "پاسخ‌گویی هوش مصنوعی موقتاً انجام نشد." },
      { status: 502 },
    );
  }
}
