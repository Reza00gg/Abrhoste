import { and, asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { chatConversations, chatMessages } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ publicId: string }> },
) {
  const user = await getCurrentUser();
  if (!user)
    return NextResponse.json({ message: "چت پیدا نشد." }, { status: 404 });

  const { publicId } = await params;
  const [chat] = await db
    .select({
      id: chatConversations.id,
      publicId: chatConversations.publicId,
      title: chatConversations.title,
      modelId: chatConversations.modelId,
      deepThinking: chatConversations.deepThinking,
    })
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.publicId, publicId),
        eq(chatConversations.userId, user.id),
      ),
    )
    .limit(1);

  if (!chat)
    return NextResponse.json({ message: "چت پیدا نشد." }, { status: 404 });

  const messages = await db
    .select({
      id: chatMessages.id,
      role: chatMessages.role,
      content: chatMessages.content,
      attachments: chatMessages.attachments,
      createdAt: chatMessages.createdAt,
    })
    .from(chatMessages)
    .where(eq(chatMessages.conversationId, chat.id))
    .orderBy(asc(chatMessages.createdAt));

  return NextResponse.json({
    chat: {
      publicId: chat.publicId,
      title: chat.title,
      modelId: chat.modelId,
      deepThinking: chat.deepThinking,
    },
    messages,
  });
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ publicId: string }> },
) {
  const user = await getCurrentUser();
  if (!user)
    return NextResponse.json({ message: "چت پیدا نشد." }, { status: 404 });

  const { publicId } = await params;
  const body = await request.json().catch(() => null);
  const deepThinking = Boolean(body?.deepThinking);

  const [chat] = await db
    .update(chatConversations)
    .set({ deepThinking, updatedAt: new Date() })
    .where(
      and(
        eq(chatConversations.publicId, publicId),
        eq(chatConversations.userId, user.id),
      ),
    )
    .returning({
      publicId: chatConversations.publicId,
      title: chatConversations.title,
      deepThinking: chatConversations.deepThinking,
    });

  if (!chat)
    return NextResponse.json({ message: "چت پیدا نشد." }, { status: 404 });

  return NextResponse.json({ chat });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ publicId: string }> },
) {
  const user = await getCurrentUser();
  if (!user)
    return NextResponse.json({ message: "چت پیدا نشد." }, { status: 404 });

  const { publicId } = await params;
  const [deleted] = await db
    .delete(chatConversations)
    .where(
      and(
        eq(chatConversations.publicId, publicId),
        eq(chatConversations.userId, user.id),
      ),
    )
    .returning({ publicId: chatConversations.publicId });

  if (!deleted)
    return NextResponse.json({ message: "چت پیدا نشد." }, { status: 404 });

  return NextResponse.json({ ok: true });
}
