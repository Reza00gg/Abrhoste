import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { chatConversations, chatMessages } from "@/db/schema";
import { ensureImageQuota, normalizeImageAttachments } from "@/lib/chat-images";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ publicId: string }> },
) {
  const user = await getCurrentUser();
  if (!user)
    return NextResponse.json(
      { message: "ابتدا اقدام به ساخت حساب/ورود به حساب کنید" },
      { status: 401 },
    );

  const { publicId } = await params;
  const [chat] = await db
    .select({ id: chatConversations.id })
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.publicId, publicId),
        eq(chatConversations.userId, user.id),
      ),
    )
    .limit(1);

  if (!chat)
    return NextResponse.json({ message: "چت پیدا نشد." }, { status: 404 });

  const body = await request.json().catch(() => null);
  const attachments = normalizeImageAttachments(body?.images);
  const role = "user";
  const content =
    String(body?.message ?? "").trim() ||
    (attachments.length ? "این تصویر را تحلیل کن." : "");
  if (!content)
    return NextResponse.json(
      { message: "پیام را وارد کنید." },
      { status: 400 },
    );
  if (content.length > 4000)
    return NextResponse.json(
      { message: "پیام بیش از حد طولانی است." },
      { status: 400 },
    );

  if (attachments.length) {
    const quota = await ensureImageQuota(user.id, attachments.length);
    if (!quota.allowed) {
      return NextResponse.json(
        {
          message: `امروز فقط ${quota.remaining} عکس دیگر می‌توانید ارسال کنید.`,
        },
        { status: 429 },
      );
    }
  }

  const [message] = await db
    .insert(chatMessages)
    .values({ conversationId: chat.id, role, content, attachments })
    .returning({
      id: chatMessages.id,
      role: chatMessages.role,
      content: chatMessages.content,
      attachments: chatMessages.attachments,
      createdAt: chatMessages.createdAt,
    });

  await db
    .update(chatConversations)
    .set({ updatedAt: new Date() })
    .where(eq(chatConversations.id, chat.id));

  return NextResponse.json({ message });
}
