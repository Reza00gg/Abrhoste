import { z } from "zod";

export const registerSchema = z.object({
  name: z.string().trim().min(2, "نام نمایشی را وارد کنید.").max(100),
  identity: z.string().trim().min(3, "ایمیل یا شماره موبایل را وارد کنید.").max(255, "ایمیل یا شماره موبایل بیش از حد طولانی است."),
  password: z.string().min(8, "رمز عبور باید حداقل ۸ کاراکتر باشد.").max(128, "رمز عبور بیش از حد طولانی است."),
  confirmPassword: z.string().min(1, "تأیید رمز عبور را وارد کنید.").max(128, "تأیید رمز عبور بیش از حد طولانی است."),
}).refine((data) => data.password === data.confirmPassword, {
  path: ["confirmPassword"],
  message: "تأیید رمز عبور با رمز عبور یکسان نیست.",
});

export const loginSchema = z.object({
  identity: z.string().trim().min(3, "ایمیل یا شماره موبایل را وارد کنید.").max(255, "ایمیل یا شماره موبایل بیش از حد طولانی است."),
  password: z.string().min(1, "رمز عبور را وارد کنید.").max(128, "رمز عبور بیش از حد طولانی است."),
});
