import { createHash, randomBytes } from "node:crypto";
import { and, eq, gt } from "drizzle-orm";
import { cookies, headers } from "next/headers";
import { db } from "@/db";
import { adminDeviceBlocks, auditLogs, sessions, users } from "@/db/schema";

const SESSION_COOKIE = "megastars_session";
const ADMIN_SESSION_COOKIE = "megastars_admin_session";
const SESSION_DAYS = 30;

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function getRequestClientInfo() {
  const requestHeaders = await headers();
  return {
    ipAddress: requestHeaders.get("x-forwarded-for")?.split(",")[0]?.trim() ?? requestHeaders.get("x-real-ip") ?? null,
    userAgent: requestHeaders.get("user-agent") ?? null,
  };
}

export async function createSession(userId: string, cookieName = SESSION_COOKIE, type: "user" | "admin" = "user") {
  const token = randomBytes(32).toString("hex");
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  const clientInfo = await getRequestClientInfo();

  await db.insert(sessions).values({
    userId,
    tokenHash,
    type,
    expiresAt,
    ipAddress: clientInfo.ipAddress,
    userAgent: clientInfo.userAgent,
  });

  const cookieStore = await cookies();
  cookieStore.set(cookieName, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: type === "admin" ? "strict" : "lax",
    path: "/",
    expires: expiresAt,
  });
}

export async function getCurrentUser() {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const result = await db
    .select({ user: users, session: sessions })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);

  return result[0]?.user ?? null;
}

export async function destroyCurrentSession(cookieName = SESSION_COOKIE) {
  const cookieStore = await cookies();
  const token = cookieStore.get(cookieName)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.tokenHash, hashToken(token)));
  }
  cookieStore.delete(cookieName);
}

export async function writeAuditLog(userId: string | null, event: string, success = true, metadata?: Record<string, unknown>) {
  const clientInfo = await getRequestClientInfo();
  await db.insert(auditLogs).values({
    userId,
    event,
    success,
    metadata: metadata ?? null,
    ipAddress: clientInfo.ipAddress,
    userAgent: clientInfo.userAgent,
  });
}

export async function isAdminClientBlocked() {
  const clientInfo = await getRequestClientInfo();
  if (!clientInfo.ipAddress || !clientInfo.userAgent) return false;
  const result = await db
    .select({ id: adminDeviceBlocks.id })
    .from(adminDeviceBlocks)
    .where(and(eq(adminDeviceBlocks.ipAddress, clientInfo.ipAddress), eq(adminDeviceBlocks.userAgent, clientInfo.userAgent)))
    .limit(1);
  return result.length > 0;
}

export async function getAdminSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(ADMIN_SESSION_COOKIE)?.value;
  if (!token) return null;
  const result = await db
    .select({ user: users, session: sessions })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  const row = result[0];
  if (!row || row.user.role !== "admin" || row.user.status !== "active" || row.user.deletedAt) return null;
  await db.update(sessions).set({ lastUsedAt: new Date(), type: "admin" }).where(eq(sessions.id, row.session.id));
  return row;
}

export async function getAdminUser() {
  const adminSession = await getAdminSession();
  return adminSession?.user ?? null;
}

export async function createAdminSession(userId: string) {
  return createSession(userId, ADMIN_SESSION_COOKIE, "admin");
}

export async function destroyAdminSession() {
  return destroyCurrentSession(ADMIN_SESSION_COOKIE);
}
