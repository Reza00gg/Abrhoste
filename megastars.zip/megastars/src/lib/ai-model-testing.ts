type TestResult = {
  ok: boolean;
  message: string;
  latencyMs: number;
};

function cleanApiModel(value: string) {
  return value.trim();
}

function isGoogleModel(value: string) {
  return (
    !value.startsWith("http") ||
    value.includes("generativelanguage.googleapis.com")
  );
}

function resolveGeminiEndpoint(apiModel: string) {
  if (apiModel.startsWith("http")) return apiModel;
  return `https://generativelanguage.googleapis.com/v1beta/models/${apiModel}:generateContent`;
}

function resolveOpenAiTarget(apiModel: string) {
  if (apiModel.includes("|")) {
    const [endpoint, model] = apiModel.split("|").map((part) => part.trim());
    return { endpoint, model };
  }
  return { endpoint: apiModel, model: "default" };
}

export async function testAiModelConnection(
  apiModelInput: string,
  apiKey: string,
): Promise<TestResult> {
  const startedAt = Date.now();
  const apiModel = cleanApiModel(apiModelInput);
  if (!apiModel || !apiKey.trim()) {
    return {
      ok: false,
      message: "نام API مدل و API Key را کامل وارد کنید.",
      latencyMs: 0,
    };
  }

  try {
    if (isGoogleModel(apiModel)) {
      const response = await fetch(resolveGeminiEndpoint(apiModel), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-goog-api-key": apiKey.trim(),
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: "فقط کلمه OK را پاسخ بده." }] }],
          generationConfig: { maxOutputTokens: 24, temperature: 0 },
        }),
      });
      const data = await response.json().catch(() => null);
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
      if (!response.ok)
        return {
          ok: false,
          message: data?.error?.message ?? "تست اتصال ناموفق بود.",
          latencyMs: Date.now() - startedAt,
        };
      return {
        ok: Boolean(text),
        message: text ? "اتصال مدل با موفقیت تست شد." : "پاسخ مدل خالی بود.",
        latencyMs: Date.now() - startedAt,
      };
    }

    const { endpoint, model } = resolveOpenAiTarget(apiModel);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey.trim()}`,
      },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: "Reply only OK" }],
        max_tokens: 24,
        temperature: 0,
      }),
    });
    const data = await response.json().catch(() => null);
    const text =
      data?.choices?.[0]?.message?.content ?? data?.choices?.[0]?.text ?? "";
    if (!response.ok)
      return {
        ok: false,
        message: data?.error?.message ?? "تست اتصال ناموفق بود.",
        latencyMs: Date.now() - startedAt,
      };
    return {
      ok: Boolean(text),
      message: text ? "اتصال مدل با موفقیت تست شد." : "پاسخ مدل خالی بود.",
      latencyMs: Date.now() - startedAt,
    };
  } catch (error) {
    return {
      ok: false,
      message: error instanceof Error ? error.message : "تست اتصال انجام نشد.",
      latencyMs: Date.now() - startedAt,
    };
  }
}
