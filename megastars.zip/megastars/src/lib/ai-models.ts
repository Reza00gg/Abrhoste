import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { aiModels } from "@/db/schema";
import { decryptModelSecret } from "@/lib/model-secrets";

export const BUILTIN_MODEL_ID = "system-gemini-3-1-flash-lite";

export const BUILTIN_MODEL = {
  id: BUILTIN_MODEL_ID,
  name: "Gemini 3.1 Flash Lite",
  apiModel: "gemini-3.1-flash-lite",
  status: "active" as const,
  builtIn: true,
  icon: "gemini",
};

export type PublicAiModel = {
  id: string;
  name: string;
  apiModel: string;
  status: string;
  builtIn: boolean;
  icon: string | null;
};

export async function getPublicAiModels() {
  const customModels = await db
    .select({
      id: aiModels.id,
      name: aiModels.name,
      apiModel: aiModels.apiModel,
      status: aiModels.status,
      icon: aiModels.icon,
    })
    .from(aiModels)
    .where(ne(aiModels.status, "hidden"));

  return [
    BUILTIN_MODEL,
    ...customModels.map((model) => ({ ...model, builtIn: false })),
  ] satisfies PublicAiModel[];
}

export async function isSelectableModel(modelId: string) {
  if (modelId === BUILTIN_MODEL_ID) return true;
  const [model] = await db
    .select({ id: aiModels.id })
    .from(aiModels)
    .where(and(eq(aiModels.id, modelId), eq(aiModels.status, "active")))
    .limit(1);
  return Boolean(model);
}

export async function getModelRuntime(modelId: string) {
  if (modelId === BUILTIN_MODEL_ID) {
    return {
      id: BUILTIN_MODEL_ID,
      name: BUILTIN_MODEL.name,
      apiModel: BUILTIN_MODEL.apiModel,
      apiKey: process.env.GEMINI_API_KEY ?? "",
      builtIn: true,
    };
  }

  const [model] = await db
    .select({
      id: aiModels.id,
      name: aiModels.name,
      apiModel: aiModels.apiModel,
      apiKeyEncrypted: aiModels.apiKeyEncrypted,
      status: aiModels.status,
    })
    .from(aiModels)
    .where(and(eq(aiModels.id, modelId), eq(aiModels.status, "active")))
    .limit(1);

  if (!model) return null;
  return {
    id: model.id,
    name: model.name,
    apiModel: model.apiModel,
    apiKey: decryptModelSecret(model.apiKeyEncrypted),
    builtIn: false,
  };
}
