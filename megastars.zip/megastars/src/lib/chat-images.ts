import { sql } from "drizzle-orm";
import { db } from "@/db";

export type ChatImageAttachment = {
  mimeType: string;
  data: string;
  name?: string;
};

export const DAILY_IMAGE_LIMIT = 5;
const MAX_IMAGES_PER_MESSAGE = 5;
const MAX_IMAGE_BASE64_CHARS = 2_200_000;
const ALLOWED_IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function normalizeImageAttachments(
  value: unknown,
): ChatImageAttachment[] {
  if (!Array.isArray(value)) return [];

  return value.slice(0, MAX_IMAGES_PER_MESSAGE).flatMap((item) => {
    if (!isPlainObject(item)) return [];
    const mimeType = String(item.mimeType ?? "").toLowerCase();
    const data = String(item.data ?? "").replace(
      /^data:image\/[a-zA-Z0-9.+-]+;base64,/,
      "",
    );
    const name = String(item.name ?? "").slice(0, 80) || undefined;

    if (!ALLOWED_IMAGE_TYPES.has(mimeType)) return [];
    if (!data || data.length > MAX_IMAGE_BASE64_CHARS) return [];
    if (!/^[a-zA-Z0-9+/=]+$/.test(data)) return [];

    return [{ mimeType, data, name }];
  });
}

export async function getUsedImageCount(userId: string) {
  const result = await db.execute<{ used: number }>(sql`
    with quota_window as (
      select greatest(
        date_trunc('day', now() at time zone 'Asia/Tehran') at time zone 'Asia/Tehran',
        coalesce((
          select max(al.created_at)
          from audit_logs al
          where al.event = 'admin_user_reset'
            and al.metadata->>'targetUserId' = ${userId}
        ), '1970-01-01'::timestamptz)
      ) as starts_at
    )
    select coalesce(sum(jsonb_array_length(coalesce(cm.attachments, '[]'::jsonb))), 0)::int as used
    from chat_messages cm
    inner join chat_conversations cc on cc.id = cm.conversation_id
    cross join quota_window qw
    where cc.user_id = ${userId}
      and cm.role = 'user'
      and cm.created_at >= qw.starts_at
  `);
  return Number(result[0]?.used ?? 0);
}

export async function getImageQuota(userId: string) {
  const used = await getUsedImageCount(userId);
  return {
    limit: DAILY_IMAGE_LIMIT,
    used,
    remaining: Math.max(0, DAILY_IMAGE_LIMIT - used),
  };
}

export async function ensureImageQuota(userId: string, imageCount: number) {
  const quota = await getImageQuota(userId);
  return { ...quota, allowed: imageCount <= quota.remaining };
}
